$(document).ready(function() {

    $("body").on("click", "#menu-sign-up", showUserSignupForm);
    $("body").on("click", "#menu-log-in", showUserLoginForm);
    $("body").on("click", "#menu-log-out", userLogOut);
    $("body").on("click", "#menu-cart", getCartProducts);


    $("body").on("click", "#menu-home", function() {
        editorial_for_search = "";
        title_for_search = "";
        extra_things = "";
        getProducts();
    });
    
    $("body").on("click", "#nav-hottest-comics", function() {
	    extra_things = "hottest";
	    title_for_search = "";
	    editorial_for_search = "";
	    getProducts();
    });
    
    $("body").on("click", "#nav-all-comics", function() {
        editorial_for_search = "";
        title_for_search = "";
        extra_things = "";
        getProducts();
    });
    
    $("body").on("click", "#nav-marvel-comics", function() {
        editorial_for_search = "Marvel";
        title_for_search = "";
        extra_things = "";
        getProducts();
    });
    
    $("body").on("click", "#nav-dc-comics", function() {
        editorial_for_search = "DC";
        title_for_search = "";
        extra_things = "";
        getProducts();
    });

    $("body").on("click", "#nav-others-comics", function() {
        editorial_for_search = "Others";
        title_for_search = "";
        extra_things = "";
        getProducts();
    });
});