const searchInput = document.getElementById('searchInput');
const searchIcon = document.getElementById('searchIcon');
const searchOverlay = document.getElementById('searchOverlay');
const searchInputExpanded = document.getElementById('searchInputExpanded');
const cancelExpandedSearch = document.getElementById('cancelExpandedSearch');

// Función para abrir el overlay y enfocar el campo de búsqueda expandido
function openSearchOverlay() {
  searchOverlay.classList.add('active');
  searchInputExpanded.focus();
}

// Mostrar el overlay cuando se hace clic en el icono de búsqueda o el input principal
searchInput.addEventListener('click', openSearchOverlay);
searchIcon.addEventListener('click', openSearchOverlay);

// Cerrar el overlay cuando se haga clic fuera de searchInputExpanded o en el overlay
document.addEventListener('click', function(event) {
  if (
    searchOverlay.classList.contains('active') &&
    !searchInputExpanded.contains(event.target) &&
    !searchInput.contains(event.target) &&
    !searchIcon.contains(event.target)
  ) {
    searchOverlay.classList.remove('active');
    searchInputExpanded.value = "";
  }
});


cancelExpandedSearch.addEventListener('click', function(event) {
  searchOverlay.classList.remove('active');
  searchInputExpanded.value = "";
  title_for_search = "";
  result_start = 0;
  getProducts();
});


searchInputExpanded.addEventListener('keydown', function(event) {
  if (event.key === "Enter") {
    title_for_search = searchInputExpanded.value;  
    result_start = 0; 
    getProducts(); 
    searchOverlay.classList.remove('active');
  }
});

document.addEventListener('keydown', function(event) {
  if (event.key === "Escape") {
    searchOverlay.classList.remove('active');
    searchInputExpanded.value = "";
  }
});

const profileDropdown = document.getElementById('profileDropdown');
function toggleDropdown() {
    profileDropdown.style.display = 'block';
}

function login() {
    document.getElementById('menu-log-in').style.display = 'none';
    document.getElementById('dropdown').style.display = 'block';
}

function logout() {
	document.getElementById('menu-log-in').style.display = 'inline-flex';
	document.getElementById('dropdown').style.display = 'none';
}