function getCartProducts() {
    if (username_login === "") {
        showUserLoginForm();
        return;
    }
    $.getJSON("get-cart-products").done(function(res) {
    	$.getJSON("get-cart-promo-code").done(function(resPromo) {
        console.log("products in cart");
        console.log(res);
        let html = Mustache.render(html_cart, res);
        $("#container").html(html);
        $(".link_show_comic_details").click(showProductDetails);
        $(".quantity-increase").on("click", increaseProductQuantity);
        $(".quantity-decrease").on("click", decreaseProductQuantity);
        $(".product-delete").on("click", deleteCartProduct);
		$("#apply-discount-button").click(apply_promo_code);

        let products_price = 0;
        let shipping_price = 4.99;
        let discount_amount = 0;
        let taxes_price = 0;
        let total_price = 0;
        let price_without_taxes = 0;
        
		if (res.length === 0) {
		    console.log("Cart is empty");
		    $("#empty-cart-message").addClass("show-cart-message");
		    $("#place-order").prop("disabled", true);
		    $("#apply-discount-button").prop("disabled", true);
		    shipping_price = 0;
		} else {
		    $("#empty-cart-message").removeClass("show-cart-message");
		    $("#place-order").prop("disabled", false);
		    $("#apply-discount-button").prop("disabled", false);
		    shipping_price = 4.99;
		}
		
        res.forEach((product, index) => {
            let productTotalPrice = product.quantity * product.price;
            products_price += productTotalPrice;

			$(`[data-price-id="${product.id}"]`).text(`${productTotalPrice.toFixed(2)} €`);
        });


		if (resPromo.length === 0) {
		} else {
		    if (resPromo.promo_code_type === "PERCENTAGE") {
		        discount_amount = (products_price * resPromo.discount) / 100;
		    } else if (resPromo.promo_code_type === "STATIC_PRICE") {
				if(products_price-resPromo.discount>0){
					discount_amount = resPromo.discount;
				}else{
					discount_amount = 0;
				}
		    } else if (resPromo.promo_code_type === "FREE_SHIPPING") {
		        discount_amount = shipping_price;
		    }
		}
		if(discount_amount<=0){
			$("#price-discount").removeClass("price-discount-show");
		}else{
			$("#price-discount").addClass("price-discount-show");
		}
        price_without_taxes = products_price / 1.21;
        taxes_price = products_price - price_without_taxes;

        total_price = (products_price + shipping_price) - discount_amount;
        
		document.querySelector(".total-amount").textContent = `${discount_amount.toFixed(2)} €`;
        document.querySelector(".sub-amount").textContent = `${price_without_taxes.toFixed(2)} €`;
        document.querySelector(".tax-amount").textContent = `${taxes_price.toFixed(2)} €`;
        document.querySelector(".shipping-amount").textContent = `${shipping_price.toFixed(2)} €`;
        document.querySelector(".discount-amount").textContent = `${discount_amount.toFixed(2)} €`;
        document.querySelector(".total-amount").textContent = `${total_price.toFixed(2)} €`;

        $("#place-order").click(checkout_step_0);
        })
    })
}

function addProductToCart() {
	if (username_login == "") {
		alert("You need to log in if you want to buy products")
		return;
	}
	let idProduct = $(this).attr("id-product")
	alert("Add to cart user the product with id" + idProduct)
	$.post("add-product-cart", {
		id: idProduct,
		quantity: 1
	}).done(function(res) {
		if (res == "ok") {
			alert("product added tothe cart correctly")
		}
	})
}

function increaseProductQuantity() {
	let idProduct = $(this).data("id");
	let quantityElement = $("#quantity-" + idProduct);
	let currentQuantity = parseInt(quantityElement.text());

	if (currentQuantity < MAX_QUANTITY) {
		$.post("increase-cart-products", {
			id: idProduct,
			quantity: 1
		}).done(function(res) {
			if (res === "ok") {
				getCartProducts();
			}
		});
	} else {
		alert("You cant order more than " + MAX_QUANTITY + " of the same comic");
	}
}

function decreaseProductQuantity() {
	let idProduct = $(this).data("id");
	let quantityElement = $("#quantity-" + idProduct);
	let currentQuantity = parseInt(quantityElement.text());

	if (currentQuantity > 1) {
		$.post("decrease-cart-products", {
			id: idProduct,
			quantity: 1
		}).done(function(res) {
			if (res === "ok") {
				getCartProducts();
			}
		});
	} else if (currentQuantity == 1) {
			deleteCartProduct.call(this);
	} else {
		alert("You cant order less than 1 comic");
	}
}

function deleteCartProduct() {
	let idProduct = $(this).data("id");
	if (confirm("¿Are you shure you want to delete this product?")) {
		$.post("delete-cart-products", {
			id: idProduct
		}).done(function(res) {
			if (res === "ok") {
				getCartProducts();
			}
		});
	}
}

function apply_promo_code(event) {
    event.preventDefault();
    let promoCode = $("#promo_code_name").val();
    if (!validatePromoCode(promoCode)) {
        console.log("Error in promo code");
        return;
    }

    $.post("apply-promo-code", { promoCode: promoCode })
        .done(function(res) {
            if (res === "ok") {
                $("#price-discount").addClass("price-discount-show");
                $("#invalid_promo_code").removeClass("show-alert");
                getCartProducts(); 
            } else {
                $("#label_discount_input").text("");
                $("#price-discount").removeClass("price-discount-show");
                $("#invalid_promo_code").addClass("show-alert");
            }
    });
}