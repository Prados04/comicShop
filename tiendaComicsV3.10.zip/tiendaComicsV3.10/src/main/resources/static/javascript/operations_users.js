function sendUserDataToServer(event) {
event.preventDefault();
    let username = $("#username").val();
    let email = $("#email").val();
    let pass = $("#pass").val();
    let pass2 = $("#pass2").val();
    let firstName = $("#name").val();
    let secondName = $("#secondName").val();
    let telNumber = $("#telNumber").val();
	
	let offers = $("#checkbox-special-offers").prop("checked");
	let newsletter = $("#checkbox-newsletter").prop("checked");
    
    let allValid = true;
    
    if (!validateUsername(username)) {
    	console.log("error in username");
        allValid = false;
    }

    if (!validatePass(pass)) {
    	console.log("error in pass");
        allValid = false;
    }

    if (!validatePass2(pass, pass2)) {
    	console.log("error in pass2");
        allValid = false;
    }

    if (!validateEmail(email)) {
    	console.log("error in email");
        allValid = false;
    }

    if (!validateFirstName(firstName)) {
    	console.log("error in firstame");
        allValid = false;
    }
    
    if (!validateSecondName(secondName)) {
    	console.log("error in secondName");
        allValid = false;
    }

    if (!validateTelNumber(telNumber)) {
    	console.log("error in telNumber");
        allValid = false;
    }


    if (!allValid) {
        console.log("Validation failed, stopping process.");
        return;
    }
	
	

    $.post("signup_client_user", {
            username: username,
            email: email,
            pass: pass,
            firstName: firstName,
            secondName: secondName,
            telNumber: telNumber,
			offers: offers,
			newsletter: newsletter
        }).done(function(res) {
            if (res == "ok") {
                alert("Gracias por crear una cuenta con nosotros")
                userLogIn(email,pass)
            }else if(res == "username-in-use"){
                $("#invalid-username").text("This username is already in use").addClass("show-alert");;
            }else if(res == "email-in-use"){
            	$("#invalid-email").text("This email is already in use").addClass("show-alert");
            }else if(res == "phone-in-use"){
            	$("#invalid-phoneNumber").text("This number is already in use").addClass("show-alert");
            }else{
            	$("#alert-incorrect-information").addClass("show-alert")
            }
    })
}
    
function userLogIn(credential,pass){
		$.post("login-user", {
			credential: credential,
			pass: pass
		}).done(function(res) {
			console.log("response received")
			if (res.operation == "ok") {
				if( $("#remember_credentials").prop("checked") ){
					Cookies.set("credential", credential, { expires:100 })
					Cookies.set("pass", pass, { expires:100 })
				}else{
					if( typeof(Cookies.get("credential")) != "undefined" ){
						Cookies.remove("credential")
					}
					if( typeof(Cookies.get("pass")) != "undefined" ){
						Cookies.remove("pass")
						$("#failed-login-alert").addClass("show-alert");
					}
				}
				username_login = res.username
				alert("Welcome to the comic shop")
				login()
				getProducts()
				$("#menu-log-out").css("visibility", "visible")
				$("#menu-my-orders").css("visibility", "visible")
				//$("#menu-log-in").hide()
			} else {
				$("#failed-login-alert").addClass("show-alert");
			}
		})
}

function showUserSignupForm() {
	$("#container").html(html_signup_user_form)
	$("#button_signup_user").click(sendUserDataToServer)
}//end showUserSignUpForm

function showUserLoginForm() {
    $("#container").html(html_login_user);
    
    // Cargar credenciales guardadas en cookies (si existen)
    if (typeof(Cookies.get("credential")) != "undefined") {
        $("#credential").val(Cookies.get("credential"));
    }
    if (typeof(Cookies.get("pass")) != "undefined") { // Corregir a "pass" en lugar de "email"
        $("#pass").val(Cookies.get("pass"));
    }

    // Escuchar el evento submit del formulario de login
    $("#form_login").submit(function(e) {
        e.preventDefault();
        if (!validateCredentialLogIn($("#credential").val())) {
            console.log("Validation failed, stopping process.");
            return;
        }
        userLogIn($("#credential").val(), $("#pass").val());
    });
}

function userLogOut() {
    $.get("user-log-out").done(function(res) {
        if (res === "ok") {
            alert("We will miss you");
            username_login = "";
            logout()
            getProducts();
        }
    });
}//end userLogOut