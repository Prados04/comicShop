let regexp_name = /^[a-z ñáéíóú]{2,20}$/i // Allows letters, spaces, and accented characters, between 2 to 20 characters
let regexp_email = /^[a-z0-9ñ._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i; // Matches common email format

// Regular expression for password validation
// Requirements:
// - Length between 6 and 30 characters
// - At least one uppercase letter (A-Z)
// - At least one digit (0-9)
// - At least one special character from the set: !@#$%^&*()_+,.?;:/\\
// - Can only contain uppercase, lowercase letters, digits, and the specified special characters
let regexp_pass = /^(?=.*[A-Zñáéíóú])(?=.*\d)(?=.*[!@#$%^&*()_+,.?;:\\])[A-Za-zñáéíóú\d!@#$%^&*()_+,.?;:\\]{6,30}$/
let regexp_username = /^[a-z0-9_ñáéíóú]{3,15}$/i // Allows letters, numbers, underscores, between 3 to 15 characters
let regexp_secondName = /^[a-z ñáéíóú]{2,25}$/i  // Allows letters, spaces, and accented characters, between 2 to 20 characters
let regexp_telNumber = /^\d{9,15}$/; // Only digits, between 9 to 15 characters

function validateCredentialLogIn(credential) {
    credential = credential.trim();
    if (credential === "") {
        $("#failed-login-alert").addClass("show-alert");
        return false;
    }else if (regexp_username.test(credential) || regexp_telNumber.test(credential) || regexp_email.test(credential)) {
        $("#invalid-username").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-username").text("Username only can contain letters, numbers, underscores, between 3 to 15 characters").addClass("show-alert");
        return false;
    }
}

function validatePassLogIn(pass){
    pass = pass.trim();
	if(pass === "") {
        $("#failed-login-alert").addClass("show-alert");
        return false;
    }else if(regexp_pass.test(pass)){
		$("#failed-login-alert").removeClass("show-alert");
		return true;
	}else{
		$("#failed-login-alert").addClass("show-alert");
		return false;
	}
}

function validateUsername(username) {
    username = username.trim();
    if (username === "") {
        $("#invalid-username").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_username.test(username)) {
        $("#invalid-username").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-username").text("Username only can contain letters, numbers, underscores, between 3 to 15 characters").addClass("show-alert");
        return false;
    }
}

function validateEmail(email) {
    email = email.trim();
    if (email === "") {
        $("#invalid-email").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_email.test(email)) {
        $("#invalid-email").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-email").text("Invalid email format").addClass("show-alert");
        return false;
    }
}

function validatePass(pass) {
    pass = pass.trim();
    if (pass === "") {
        $("#invalid-password").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_pass.test(pass)) {
        $("#invalid-password").removeClass("show-alert");
        return true;
    } else {
	$("#invalid-password").html("Requirements:<br/>" +
	    "- Length between 6 and 30 characters<br/>" +
	    "- At least one uppercase letter (A-Z)<br/>" +
	    "- At least one digit (0-9)<br/>" +
	    "- At least one special character from the set: !@#$%^&*()_+,.?;:\\<br/>").addClass("show-alert");
        return false;
    }
}

function validatePass2(pass, pass2) {
    pass = pass.trim();
    pass2 = pass2.trim();
    if (pass === "" || pass2 === "") {
        $("#invalid-password2").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (pass === pass2) {
        $("#invalid-password2").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-password2").text("The passwords don't match").addClass("show-alert");
        return false;
    }
}

function validateFirstName(firstName) {
    firstName = firstName.trim();
    if (firstName === "") {
        $("#invalid-name").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_name.test(firstName)) {
        $("#invalid-name").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-name").text("Only letters, spaces between 2 to 20 characters").addClass("show-alert");
        return false;
    }
}

function validateSecondName(secondName) {
    secondName = secondName.trim();
    if (secondName === "") {
        $("#invalid-secondName").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_secondName.test(secondName)) {
        $("#invalid-secondName").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-secondName").text("Only letters, spaces between 2 to 25 characters").addClass("show-alert");
        return false;
    }
}

function validateTelNumber(telNumber) {
    telNumber = telNumber.trim();
    if (telNumber === "") {
        $("#invalid-phoneNumber").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_telNumber.test(telNumber)) {
        $("#invalid-phoneNumber").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-phoneNumber").text("Only digits, between 9 to 15 characters").addClass("show-alert");
        return false;
    }
}