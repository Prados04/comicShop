let regexp_shippingName = /^[a-z ñáéíóú]{2,30}$/i; // Allows letters, spaces, and accented characters, between 2 to 10 characters
let regexp_phoneNumber = /^\d{9,15}$/; // Only digits, between 9 to 15 characters
let regexp_city = /^[a-z ñáéíóú]{2,30}$/i; // Allows letters, spaces, and accented characters, between 2 to 50 characters
let regexp_country = /^[a-z ñáéíóú]{2,30}$/i; // Allows letters, spaces, and accented characters, between 2 to 50 characters
let regexp_province = /^[a-z ñáéíóú]{2,30}$/i; // Allows letters, spaces, and accented characters, between 2 to 50 characters
let regexp_address = /^[a-z0-9 \/ñáéíóú#.,_//-º]{5,100}$/i; // Allows letters, numbers, spaces, and certain special characters, between 5 to 100 characters
let regexp_zipCode = /^\d{5,10}$/i; // Only digits, between 5 to 10 characters (common for ZIP codes)

let regexp_extraShippingInformation = /^[a-z0-9 ñáéíóú.,#-]{0,100}$/i; // Allows letters, numbers, spaces, and common punctuation, up to 100 characters
let regexp_timesReadComics = /^[0-9+-]{1,3}(-[0-9]{1,2})?$/i; // All digits 0-5 characters

let regexp_cardType = /^[a-zA-Z_\s]+$/; // Allows letters and spaces for card types
let regexp_cardNumber = /^\d{10,20}$/; // 10 to 20 digits for card numbers
let regexp_cardHolder = /^[a-zA-Z ñáéíóú]{3,50}$/; // Allows letters, spaces, and accented characters, between 3 to 50 characters
let regexp_cardExpirationDate = /^(0[1-9]|1[0-2])\/?([0-9]{2})$/; // MM/YY format
let regexp_cardCVV = /^\d{3,4}$/; // 3 or 4 digits for CVV

let regexp_promoCode = /^[a-z0-9ñáéíóú._#-]{0,20}$/i;

function validatePromoCode(promoCode){
	promoCode = promoCode.trim();
	if (promoCode === "") {
	    $("#label_discount_input").text("");
		$("#invalid_promo_code").addClass("show-alert")
	    return false;
	} else if (regexp_promoCode.test(promoCode)) {
	    $("#invalid_promo_code").removeClass("show-alert");
	    return true;
	} else {
		$("#label_discount_input").text("");
		$("#invalid_promo_code").addClass("show-alert")
	    return false;
	}
}

function validateUsername(name) {
    name = name.trim();
    if (name === "") {
        $("#invalid-name").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_username.test(name)) {
        $("#invalid-name").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-name").text("Username only can contain letters, numbers, underscores, between 3 to 15 characters").addClass("show-alert");
        return false;
    }
}

function validateShippingName(fullName) {
    fullName = fullName.trim();
    if (fullName === "") {
        $("#invalid-name").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_shippingName.test(fullName)) {
        $("#invalid-name").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-name").text("Incorrect shipping name: Only letters, from 2 to 30 characters").addClass("show-alert");
        return false;
    }
}

function validatePhoneNumber(phoneNumber) {
    phoneNumber = phoneNumber.trim();
    if (phoneNumber === "") {
        $("#invalid-phone_number").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_phoneNumber.test(phoneNumber)) {
        $("#invalid-phone_number").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-phone_number").text("Incorrect phone number: Only digits, from 9 to 15 characters").addClass("show-alert");
        return false;
    }
}

function validateCity(city) {
    city = city.trim();
    if (city === "") {
        $("#invalid-city").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_city.test(city)) {
        $("#invalid-city").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-city").text("Incorrect city name: Only letters, from 2 to 30 characters").addClass("show-alert");
        return false;
    }
}

function validateCountry(country) {
    country = country.trim();
    if (country === "") {
        $("#invalid-country").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_country.test(country)) {
        $("#invalid-country").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-country").text("Incorrect country name: Only letters, from 2 to 30 characters").addClass("show-alert");
        return false;
    }
}

function validateProvince(province) {
    province = province.trim();
    if (province === "") {
        $("#invalid-province").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_province.test(province)) {
        $("#invalid-province").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-province").text("Incorrect province name: Only letters, from 2 to 30 characters").addClass("show-alert");
        return false;
    }
}

function validateAddress(address) {
    address = address.trim();
    if (address === "") {
        $("#invalid-address").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_address.test(address)) {
        $("#invalid-address").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-address").text("Incorrect address: Must be between 5 to 100 characters, including letters, numbers, and special characters (#,.,-)").addClass("show-alert");
        return false;
    }
}

function validateZipCode(zipCode) {
    zipCode = zipCode.trim();
    if (zipCode === "") {
        $("#invalid-zip-code").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_zipCode.test(zipCode)) {
        $("#invalid-zip-code").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-zip-code").text("Incorrect ZIP code: Only digits, from 5 to 10 characters").addClass("show-alert");
        return false;
    }
}

function validateExtraShippingInformation(info) {
    info = info.trim();
	if (regexp_extraShippingInformation.test(info)) {
        $("#invalid-extra-shipping-info").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-extra-shipping-info").text("Incorrect extra shipping information: Allowed characters include letters, numbers, and common punctuation (max 100 characters)").addClass("show-alert");
        return false;
    }
}

function validateTimesReadComics(timesReadComics) {
    timesReadComics = timesReadComics.trim();
    if (timesReadComics === "") {
        $("#invalid-times-read-comics").text("Please select an option").addClass("show-alert");
        return false;
    } else if(timesReadComics === "-1"){
        $("#invalid-times-read-comics").text("Please select an option").addClass("show-alert");
        return false;
    }else if (regexp_timesReadComics.test(timesReadComics)) {
        $("#invalid-times-read-comics").removeClass("show-alert");
        return true;
    }else {
        $("#invalid-times-read-comics").text("Please select an option").addClass("show-alert");
        return false;
    }
}

function validateCardType(type) {
    type = type.trim();
    if (type === "-1") {
        $("#invalid-card-type").text("Please select a card type").addClass("show-alert");
        return false;
    } else if (regexp_cardType.test(type)) {
        $("#invalid-card-type").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-card-type").text("Please select a card type").addClass("show-alert");
        return false;
    }
}

function validateCardNumber(number) {
    number = number.trim();
    if (number === "") {
        $("#invalid-card-number").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_cardNumber.test(number)) {
        $("#invalid-card-number").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-card-number").text("Incorrect card number: Must be between 10 and 20 digits").addClass("show-alert");
        return false;
    }
}

function validateCardHolder(holder) {
    holder = holder.trim();
    if (holder === "") {
        $("#invalid-card-holder").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_cardHolder.test(holder)) {
        $("#invalid-card-holder").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-card-holder").text("Incorrect cardholder name: Only letters and spaces (3 to 50 characters)").addClass("show-alert");
        return false;
    }
}

function validateCardExpirationDate(expirationDate) {
    expirationDate = expirationDate.trim();
    if (expirationDate === "/") {
        $("#invalid-card-expiration-date").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_cardExpirationDate.test(expirationDate)) {
        $("#invalid-card-expiration-date").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-card-expiration-date").text("Incorrect expiration format must be MM/YY").addClass("show-alert");
        return false;
    }
}

function validateCardCVV(cvv) {
    cvv = cvv.trim();
    if (cvv === "") {
        $("#invalid-card-cvv").text("Please fill in the field").addClass("show-alert");
        return false;
    } else if (regexp_cardCVV.test(cvv)) {
        $("#invalid-card-cvv").removeClass("show-alert");
        return true;
    } else {
        $("#invalid-card-cvv").text("Incorrect CVV: Must be 3 or 4 digits").addClass("show-alert");
        return false;
    }
}