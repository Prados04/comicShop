function checkout_step_0(event) {
    event.preventDefault();

    let productsPrice = parseFloat(document.querySelector(".sub-amount").textContent.replace("€", "").trim());
    let shippingPrice = parseFloat(document.querySelector(".shipping-amount").textContent.replace("€", "").trim());
    let discountAmount = parseFloat(document.querySelector(".discount-amount").textContent.replace("€", "").trim());
    let taxesPrice = parseFloat(document.querySelector(".tax-amount").textContent.replace("€", "").trim());
    let totalPrice = parseFloat(document.querySelector(".total-amount").textContent.replace("€", "").trim());

    $.post("place-order-step-00", {
        productsPrice: productsPrice,
        shippingPrice: shippingPrice,
        discountAmount: discountAmount,
        taxesPrice: taxesPrice,
        totalPrice: totalPrice
    }).done(function(res) {
        if (res === "ok") {
            $("#container").html(html_checkout_01);
            $("#accept_step_01").click(checkout_step_01_accept);
        } else {
            alert("Error while starting the checkout: " + res);
        }
    });
}
function checkout_step_01_accept(event){
	event.preventDefault();
	let fullName = $("#name_field").val()
	let phoneNumber = $("#phone_number_field").val()
	let city = $("#city_field").val()
	let country = $("#country_field").val()
	let province = $("#province_field").val()
	let address = $("#address_field").val()
	let zipCode = $("#zip_code_field").val()

	let allValid = true;
	

	if (!validateShippingName(fullName)) {
	    console.log("Error in shipping name");
	    allValid = false;
	}
	
	
	if (!validatePhoneNumber(phoneNumber)) {
	    console.log("Error in phone number");
	    allValid = false;
	}
	
	
	if (!validateCity(city)) {
	    console.log("Error in city");
	    allValid = false;
	}
	
	
	if (!validateCountry(country)) {
	    console.log("Error in country");
	    allValid = false;
	}
	
	
	if (!validateProvince(province)) {
	    console.log("Error in province");
	    allValid = false;
	}
	
	
	if (!validateAddress(address)) {
	    console.log("Error in address");
	    allValid = false;
	}
	
	
	if (!validateZipCode(zipCode)) {
	    console.log("Error in zip code");
	    allValid = false;
	}
	
	
	if (!allValid) {
	    console.log("Validation failed, stopping process.");
	    return;
	}
	
	$.post("place-order-step-01",{
		fullName: fullName,
		phoneNumber: phoneNumber,
		address: address,
		zipCode: zipCode,
		province: province,
		city: city,
		country: country
	}).done(function(res){
		if(res == "ok"){
			$("#container").html(html_checkout_02)
			$("#accept_step_02").click(checkout_step_02_accept)
		}else{
			alert(res)
		}
	})
}


function checkout_step_02_accept(event){
	event.preventDefault();
	let extraShippmentInformation = $("#extraShippmentInformation").val()
	let timesReadComics = $("#timesReadComics").find(":selected").val()
	
	let allValid = true;
	if (!validateExtraShippingInformation(extraShippmentInformation)) {
	    allValid = false;
	}
	if (!validateTimesReadComics(timesReadComics)){
		allValid = false;
	}
	if (!allValid) {
	    console.log("Validation failed, stopping process.");
	    return;
	}
	
	$.post("place-order-step-02",{
		extraShippmentInformation: extraShippmentInformation,
		timesReadComics, timesReadComics
	}).done(function(res){
		if(res == "ok"){
			$("#container").html(html_checkout_03)
			$("#accept_step_03").click(checkout_step_03_accept)
		}else{
			alert(res)
		}
	})	
}

function checkout_step_03_accept(event){
	event.preventDefault();
	let cardType = $("#card_type_field").find(":selected").val()
	let cardNumber = $("#card_number_field").val()
	let cardHolder = $("#card_holder_field").val()
	let cardExpirationMonth = $("#card_expiration_month_field").val()
	let cardExpirationYear = $("#card_expiration_year_field").val()
	let cardCVV = $("#card_cvv_field").val()
	
	let cardExpirationDate = cardExpirationMonth+"/"+cardExpirationYear;
	
	let allValid = true;
	
	if (!validateCardType(cardType)) {
	    allValid = false;
	}
	if (!validateCardNumber(cardNumber)) {
	    allValid = false;
	}
	if (!validateCardHolder(cardHolder)) {
	    allValid = false;
	}
	if (!validateCardExpirationDate(cardExpirationDate)) {
	    allValid = false;
	}
	if (!validateCardCVV(cardCVV)) {
	    allValid = false;
	}
	
	if (!allValid) {
	    console.log("Validation failed, stopping process.");
	    return;
	}
	
	$.post("place-order-step-03",{
		cardType: cardType,
		cardNumber: cardNumber,
		cardExpirationDate: cardExpirationDate,
		cardCVV: cardCVV,
		cardHolder: cardHolder
	}).done(function(res){
		console.log(res.discountAmount);
			let html = Mustache.render(html_checkout_04, res)
			$("#container").html(html)
			$("#confirm_order_button").click(confirm_order)
			if (res.discountAmount>0) {
					$("#price-discount-checkout").addClass("price-discount-show");
				}else{
					$("#price-discount-checkout").removeClass("price-discount-show");
			}
	})
}

function confirm_order(event){
	event.preventDefault();
	$.post("confirm-order").done(function(res){
		if(res == "ok"){
			alert("Thanks for ordering comics with us")
			getProducts()
		}else{
			alert("Something went wrong")
		}
	})
}