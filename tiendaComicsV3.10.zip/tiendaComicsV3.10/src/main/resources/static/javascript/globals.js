const MAX_QUANTITY = 10;
let username_login = ""
let language_suffix = ""
let carouselInterval;
let title_for_search = ""
let editorial_for_search = ""
let result_start = 0
let extra_things = ""