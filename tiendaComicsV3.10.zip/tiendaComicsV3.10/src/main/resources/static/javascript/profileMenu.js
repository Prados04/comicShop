// Manejo del icono y menú de perfil
$(document).ready(function () {
    // Mostrar/ocultar el menú desplegable de perfil cuando se hace clic en el icono
    $("#profile-icon").click(function (event) {
        event.preventDefault();
        $("#profile-dropdown-menu").toggle(); // Alterna visibilidad
    });

    // Ocultar el menú al hacer clic fuera de él
    $(document).click(function (event) {
        if (!$(event.target).closest('.header-profile-menu').length) {
            $("#profile-dropdown-menu").hide();
        }
    });

    // Manejo de la opción "Log Out"
    $("#log-out-link").click(function (event) {
        event.preventDefault();
        userLogOut(); // Llama a tu función de cierre de sesión
    });
});