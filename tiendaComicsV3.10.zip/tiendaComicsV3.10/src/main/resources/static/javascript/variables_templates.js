let html_signup_user_form = ""
let html_products_list = ""
let html_login_user = ""
let html_comic_details = ""
let html_cart = ""
let html_checkout_01 = ""
let html_checkout_02 = ""
let html_checkout_03 = ""
let html_checkout_04 = ""

	$.get("templates"+ language_suffix +"/signup_user_form.html").
		done(function(res){
			html_signup_user_form = res
		})
	$.get("templates"+ language_suffix +"/products_list.html").
		done(function(res){
			html_products_list = res
		})
	$.get("templates"+ language_suffix +"/login_user_form.html").
		done(function(res){
			html_login_user = res
		})
	$.get("templates"+ language_suffix +"/comic-details.html").
		done(function(res){
			html_comic_details = res
		})
	$.get("templates"+ language_suffix +"/cart.html").
		done(function(res){
			html_cart = res
		})
	$.get("templates"+ language_suffix +"/checkout_01.html").
		done(function(res){
			html_checkout_01 = res
		})
	$.get("templates"+ language_suffix +"/checkout_02.html").
		done(function(res){
			html_checkout_02 = res
		})
	$.get("templates"+ language_suffix +"/checkout_03.html").
		done(function(res){
			html_checkout_03 = res
		})
	$.get("templates"+ language_suffix +"/checkout_04.html").
		done(function(res){
			html_checkout_04 = res
		})
