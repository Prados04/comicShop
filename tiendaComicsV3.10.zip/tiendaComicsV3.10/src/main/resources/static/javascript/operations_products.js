function getProducts() {
	$.post("get-products-json", {
		title: title_for_search,
		start: result_start,
		editorial: editorial_for_search,
		extra_things: extra_things
	}).done(function(res) {
		let comics = res.comics;
		console.log(comics);
		let text_html = Mustache.render(html_products_list, comics);
		$("#container").html(text_html);
		$(".link_show_comic_details").click(showProductDetails);
		initCarousel();
		$("#total_results").html(res.comicsTotal);
		if(res.comicsTotal<=0){
			$("#no-results").addClass("no-results-show")
		}else{
			$("#no-results").removeClass("no-results-show")
		}
		$("#searchInputExpanded").val(title_for_search);
		$("#searchInput").val(title_for_search);
		$("#searchInputExpanded").focus();
		
		if ((result_start + 10) < res.comicsTotal) {
			$("#link_next").show();
		} else {
			$("#link_next").hide();
		}

		$("#link_next").off("click").click(function() {
			result_start += 10;
			getProducts();
		});

		if (result_start > 0) {
			$("#link_previous").show();
		} else {
			$("#link_previous").hide();
		}

		$("#link_previous").off("click").click(function() {
			result_start -= 10;
			getProducts();
		});
	});
}

function showProductDetails() {
	let idProduct = $(this).attr("id-product");
	$.getJSON("get-comic-details", {
		id: idProduct
	}).done(function(res) {
		let html = Mustache.render(html_comic_details, res);
		$("#container").html(html);
		$("#link_add_to_cart").click(addProductToCart);
	});
}

$("#searchInputExpanded").keyup(function(e) {
	title_for_search = $(this).val();
	result_start = 0;
	getProducts();
});