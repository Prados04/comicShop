package com.prados.tiendaComics.serviceSetUp;

public interface SetUp {
	void setUp();
}
