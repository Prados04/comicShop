package com.prados.tiendaComics.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prados.tiendaComics.model.PromoCode;
import com.prados.tiendaComics.model.PromoCodeState;
import com.prados.tiendaComics.model.PromoCodeType;
import com.prados.tiendaComics.services.PromoCodesService;


@Controller
@RequestMapping("admin/")
public class PromoCodeController {
	
	@Autowired
	private PromoCodesService servicePromoCodes;
	
	@RequestMapping("promoCodes")
	public String getPromoCodes(Model model) {
		List<PromoCode> promoCodes =  servicePromoCodes.getPromoCodes();
		model.addAttribute("promoCodes",promoCodes);
		return "admin/promoCodes";
	}
	
	@RequestMapping("promoCodes-delete")
	public String deletePromoCode(String id, Model model) {
		servicePromoCodes.deletePromoCode(Integer.parseInt(id));
		return getPromoCodes(model);
	}
	
	@RequestMapping("promoCodes-new")
	public String newPromoCode(Model model) {
		System.err.println("New promoCode");
		PromoCode c = new PromoCode();
		model.addAttribute("newPromoCode", c);
		model.addAttribute("promoCodes", servicePromoCodes.getPromoCodes());
		model.addAttribute("PromoCodeTypes", PromoCodeType.values());
		model.addAttribute("PromoCodeState", PromoCodeState.values());
		return "admin/new-promoCode";
	}
	
	@RequestMapping("promoCodes-save")
	public String saveNewPromoCode(@ModelAttribute("newPromoCode") @Valid PromoCode newPromoCode, BindingResult br, Model model, HttpServletRequest  request ) {
		if (br.hasErrors()) {
			model.addAttribute("promoCodes", servicePromoCodes.getPromoCodes());
			model.addAttribute("PromoCodeTypes", PromoCodeType.values());
			model.addAttribute("PromoCodeState", PromoCodeState.values());
			return "admin/new-promoCode";
		}
		servicePromoCodes.registerPromoCode(newPromoCode);
		return getPromoCodes(model);
	}
	
	@RequestMapping("promoCodes-edit")
	public String editPromoCode(String id, Model model) {
		PromoCode u=servicePromoCodes.getPromoCodeById(Integer.parseInt(id));
		model.addAttribute("editPromoCode", u);
		model.addAttribute("promoCodes", servicePromoCodes.getPromoCodes());
		model.addAttribute("PromoCodeTypes", PromoCodeType.values());
		model.addAttribute("PromoCodeState", PromoCodeState.values());
		return "admin/edit-promoCode";
	}
	
	@RequestMapping("promoCodes-save-changes")
	public String saveChangesPromoCode(@ModelAttribute("editPromoCode") @Valid PromoCode editPromoCode, BindingResult br, Model model, HttpServletRequest request) {
		if (br.hasErrors()) {
			return "admin/edit-promoCode";
		}
		servicePromoCodes.updatePromoCode(editPromoCode);
		model.addAttribute("PromoCodeTypes", PromoCodeType.values());
		model.addAttribute("PromoCodeState", PromoCodeState.values());
		return getPromoCodes(model);
	}
}
