package com.prados.tiendaComics.services;

import java.util.List;

import com.prados.tiendaComics.model.Order;
import com.prados.tiendaComics.model.ExtraTypes.OrderSummary;

public interface OrderService {

	
	//Client part
	void processStep01(String fullName, String phoneNumber, String address, String zipCode, String province, String city, String country, long idUser);
	void processStep02(String extraShippmentInformation, String timesReadComics, long idUser);
	void processStep03(String cardType, String cardNumber, String cardHolder, String cardExpirationDate, String cardCVV, long idUser);
	void processStep00(double productsPrice, double taxesPrice, double shippingPrice, double discountAmount, double totalPrice, long id);
	OrderSummary getOrderSummary(long idUser);
	void confirmOrder(long idUser);
	
	
	//Admin part
	List<Order> getOrders();
	Order getOrderById(long id);
	void updateOrderState(long id, String state);

}
