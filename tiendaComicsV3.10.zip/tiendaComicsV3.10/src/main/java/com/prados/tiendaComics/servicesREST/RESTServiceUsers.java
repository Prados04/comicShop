package com.prados.tiendaComics.servicesREST;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.prados.tiendaComics.model.User;
import com.prados.tiendaComics.services.UsersService;
import com.prados.tiendaComics.servicesREST.response.LoginResponse;
import com.prados.tiendaComics.validationConstants.ValidationConstants;

@RestController
public class RESTServiceUsers {
	@Autowired
	private UsersService usersService;
	
	@RequestMapping("signup_client_user")
	public String signupUser(String username, String pass, String email, String firstName, String secondName, String telNumber, boolean offers, boolean newsletter){
		
		if ( usersService.checkExistUsername(username) ) {
			return "username-in-use";
		}
		if ( usersService.checkExistEmail(email) ) {
			return "email-in-use";
		}
		if ( usersService.checkExistPhoneNumber(telNumber) ) {
			return "phone-in-use";
		}
		
		Pattern patternName = Pattern.compile(ValidationConstants.regExpNameUserSignUp, Pattern.CASE_INSENSITIVE);
		Pattern patternEmail = Pattern.compile(ValidationConstants.regExpEmailUserSignUp, Pattern.CASE_INSENSITIVE);
		Pattern patternPass = Pattern.compile(ValidationConstants.regExpPassUserSignUp, Pattern.CASE_INSENSITIVE);
		Pattern patternUsername = Pattern.compile(ValidationConstants.regExpUsernameUserSignUp, Pattern.CASE_INSENSITIVE);
		Pattern patternSecondName = Pattern.compile(ValidationConstants.regExpSecondNameUserSignUp, Pattern.CASE_INSENSITIVE);
		Pattern patternTelNumber = Pattern.compile(ValidationConstants.regExpTelNumberUserSignUp, Pattern.CASE_INSENSITIVE);
		
		Matcher matchesName = patternName.matcher(firstName.trim());
		Matcher matchesEmail = patternEmail.matcher(email.trim());
		Matcher matchesPass = patternPass.matcher(pass.trim());
		Matcher matchesUsername = patternUsername.matcher(username.trim());
		Matcher matchesSecondName = patternSecondName.matcher(secondName.trim());
		Matcher matchesTelNumber = patternTelNumber.matcher(telNumber.trim());
		
		if (!matchesName.matches()) {
		    return "incorrect name from server side";
		}
		if (!matchesEmail.matches()) {
		    return "incorrect email from server side";
		}
		if (!matchesPass.matches()) {
		    return "incorrect password from server side";
		}
		if (!matchesUsername.matches()) {
		    return "incorrect username from server side";
		}
		if (!matchesSecondName.matches()) {
		    return "incorrect second name from server side";
		}
		if (!matchesTelNumber.matches()) {
		    return "incorrect telephone number from server side";
		}
		
		User u = new User(username, email, pass, firstName, secondName, telNumber);	
		u.getExtraUserInformation().setOffers(offers);
		u.getExtraUserInformation().setNewsletter(newsletter);
		usersService.signUpUser(u);
		return "ok";
		
	}
	
	@RequestMapping("login-user")
	public LoginResponse identifyUser(
			String credential, String pass, HttpServletRequest request){
		
		Pattern patternEmail = Pattern.compile(ValidationConstants.regExpEmailUserSignUp);
		Pattern patternTelNumber = Pattern.compile(ValidationConstants.regExpEmailUserSignUp);
		Pattern patternUsername = Pattern.compile(ValidationConstants.regExpEmailUserSignUp);
		Pattern patternPass = Pattern.compile(ValidationConstants.regExpPassUserSignUp);
		
		Matcher matchesEmail = patternEmail.matcher(credential);
		Matcher matchesTelNumber = patternTelNumber.matcher(credential);
		Matcher matchesUsername = patternUsername.matcher(credential);
		Matcher matchesPass = patternPass.matcher(pass);

		LoginResponse rl = null;
		if (!matchesEmail.matches() && !matchesTelNumber.matches() && !matchesUsername.matches()) {
			rl = new LoginResponse("no-ok-invalid-credential","");
		}
		if (!matchesPass.matches()) {
			rl = new LoginResponse("no-ok-invalid-pass","");
		}
		
		User u = usersService.getUserByCredentialAndPass(credential, pass);

		if (u != null) {
			rl = new LoginResponse("ok", u.getUsername());
			request.getSession().setAttribute("user", u);
		}else {
			rl = new LoginResponse("no-ok","");
		}
		return rl;
	}
	
	@RequestMapping("user-log-out")
	public String logOutUser(HttpServletRequest request) {
		request.getSession().invalidate();
		return "ok";
	}
}
