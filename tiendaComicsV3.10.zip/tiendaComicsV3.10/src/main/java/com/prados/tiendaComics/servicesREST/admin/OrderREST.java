package com.prados.tiendaComics.servicesREST.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.prados.tiendaComics.services.OrderService;

@RestController
@RequestMapping("admin/")
public class OrderREST {

	@Autowired
	private OrderService orderService;
	
    @RequestMapping("administration-update-order-state")
    public String updateOrderState(@RequestParam("id") long id, @RequestParam("state") String state) {
        orderService.updateOrderState(id, state); // Asegúrate de que el método existe en OrderService
        return "order updated";
    }
}
