package com.prados.tiendaComics.controllers;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prados.tiendaComics.model.Category;
import com.prados.tiendaComics.services.CategoriesService;

@Controller
@RequestMapping("admin/")
public class CategoriesController {
	
	@Autowired
	private CategoriesService serviceCategories;
	
	@RequestMapping("categories")
	public String getCategories(Model model) {
		List<Category> categories =  serviceCategories.getCategories();
		model.addAttribute("categories",categories);
		return "admin/categories";
	}
	
	@RequestMapping("categories-delete")
	public String deleteCategory(String id, Model model) {
		serviceCategories.deleteCategory(Integer.parseInt(id));
		return getCategories(model);
	}
	
	@RequestMapping("categories-new")
	public String newCategory(Model model) {
		System.err.println("New category");
		Category c = new Category();
		model.addAttribute("newCategory", c);
		model.addAttribute("categories", serviceCategories.getCategories());
		return "admin/new-category";
	}
	
	@RequestMapping("categories-save")
	public String saveNewCategory(@ModelAttribute("newCategory") @Valid Category newCategory, BindingResult br, Model model, HttpServletRequest  request ) {
		if (br.hasErrors()) {
			model.addAttribute("categories", serviceCategories.getCategories());
			return "admin/new-category";
		}
		serviceCategories.registerCategory(newCategory);
		return getCategories(model);
	}
	
	@RequestMapping("categories-edit")
	public String editCategory(String id, Model model) {
		Category c=serviceCategories.getCategoryById(Integer.parseInt(id));
		model.addAttribute("editCategory", c);
		model.addAttribute("categories", serviceCategories.getCategories());
		return "admin/edit-category";
	}
	
	@RequestMapping("categories-save-changes")
	public String saveChangesCategory(@ModelAttribute("editCategory") @Valid Category editCategory, BindingResult br, Model model, HttpServletRequest request) {
		if (br.hasErrors()) {
			return "admin/edit-category";
		}
		serviceCategories.updateCategory(editCategory);
		return getCategories(model);
	}
}
