package com.prados.tiendaComics.servicesREST;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.prados.tiendaComics.model.ExtraTypes.ComicListInfo;
import com.prados.tiendaComics.services.ComicsService;

import net.bytebuddy.implementation.bytecode.constant.DefaultValue;

@RestController
public class RESTServiceProducts {

	@Autowired
	private ComicsService comicsService;
	
	@RequestMapping("get-products-json")
	public ComicListInfo getProductsJSON(
	    @RequestParam(name = "title", defaultValue = "") String title,
	    @RequestParam(name = "start", defaultValue = "0") Integer start,
	    @RequestParam(name = "editorial", defaultValue = "") String editorial,
	    @RequestParam(name = "extra_things", defaultValue = "") String extra_things
	) {
	    ComicListInfo info = new ComicListInfo();
	    info.setComics(comicsService.getComicsForList(title, start, editorial, extra_things));
	    info.setComicsTotal(comicsService.getTotalComics(title, editorial, extra_things));
	    return info;
	}
	
	@RequestMapping("get-comic-details")
	public String getComicDetails(@RequestParam("id") Long id) {
		return new Gson().toJson(comicsService.getComicViewDetailsById(id));
	}
}
