package com.prados.tiendaComics.controllers;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.prados.tiendaComics.model.Category;
import com.prados.tiendaComics.model.Comic;
import com.prados.tiendaComics.services.CategoriesService;
import com.prados.tiendaComics.services.ComicsService;

@Controller
@RequestMapping("admin/")
public class ComicsController {
	
	@Autowired
	private ComicsService serviceComics;
	
	@Autowired
	private CategoriesService serviceCategories;
	
	@RequestMapping("comics")
	public String getComics(@RequestParam(name = "title", defaultValue = "") String title, @RequestParam(name="start", defaultValue="0") Integer start, Model model) {
		List<Comic> comics =  serviceComics.getComics(title,start,10);
		int totalComics = serviceComics.getTotalComics(title); 
		model.addAttribute("comics",comics);
		model.addAttribute("title", title);
		model.addAttribute("next",start + 10);
		model.addAttribute("previous",start - 10);
		model.addAttribute("total", totalComics);
		return "admin/comics";
	}
	
	@RequestMapping("comics-delete")
	public String deleteComic(String id, Model model) {
		serviceComics.deleteComic(Long.parseLong(id));
		return getComics("",0,model);
	}
	
	@RequestMapping("comics-new")
	public String newComic(Model model) {
		System.err.println("New comic");
		Comic c = new Comic();
		c.setPrice((double) 1);
		model.addAttribute("newComic", c);
		model.addAttribute("categories", serviceCategories.getCategories());
		return "admin/new-comic";
	}
	@RequestMapping("comics-save")
	public String saveNewComic(@ModelAttribute("newComic") @Valid Comic newComic, BindingResult br, Model model, HttpServletRequest  request ) {
	    if (br.hasErrors()) {
	        model.addAttribute("categories", serviceCategories.getCategories());
	        return "admin/new-comic";
	    }
	    
	    try {
	        newComic.setPortraitImage(newComic.getUploadFile().getBytes());
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    newComic.setLastChangeDate(new Date());
	    serviceComics.registerComic(newComic);
	    return getComics("",0,model);
	}
	
	@RequestMapping("comics-edit")
	public String editComic(String id, Model model) {
		Comic c=serviceComics.getComicById(Long.parseLong(id));
		model.addAttribute("editComic", c);
		model.addAttribute("categories", serviceCategories.getCategories());
		return "admin/edit-comic";
	}
	
	@RequestMapping("comics-save-changes")
	public String saveChangesComic(@ModelAttribute("editComic") @Valid Comic editComic, BindingResult br, Model model, HttpServletRequest request) {
	    if (br.hasErrors()) {
	        return "admin/edit-comic";
	    }

	    // Fetch the managed entity from the database
	    Comic managedComic = serviceComics.getComicById(editComic.getId());

	    if (managedComic == null) {
	        // Handle the case where the comic doesn't exist
	        model.addAttribute("error", "Comic not found");
	        return "admin/edit-comic";
	    }

	    // Update the managed entity with the edited data
	    managedComic.setTitle(editComic.getTitle());
	    managedComic.setEditorial(editComic.getEditorial());
	    managedComic.setAuthor(editComic.getAuthor());
	    managedComic.setIsbn(editComic.getIsbn());
	    managedComic.setDescription(editComic.getDescription());
	    managedComic.setReleaseDate(editComic.getReleaseDate());
	    managedComic.setSeries(editComic.getSeries());
	    managedComic.setPrice(editComic.getPrice());

	    if (editComic.getUploadFile() != null && !editComic.getUploadFile().isEmpty()) {
	        try {
	            managedComic.setPortraitImage(editComic.getUploadFile().getBytes());
	        } catch (IOException e) {
	            e.printStackTrace();
	            model.addAttribute("imageError", "Error processing the image.");
	            return "admin/edit-comic";
	        }
	    }

	    Category category = serviceCategories.getCategoryById(editComic.getIdCategory());
	    managedComic.setCategory(category);
	    managedComic.setLastChangeDate(new Date());

	    serviceComics.updateComic(managedComic);
	    return getComics("",0,model);
	}
}
