package com.prados.tiendaComics.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prados.tiendaComics.model.Order;
import com.prados.tiendaComics.model.orderState.OrderState;
import com.prados.tiendaComics.services.OrderService;

@Controller
@RequestMapping("admin/")
public class OrdersController {

	@Autowired
	private OrderService orderService;
	
	@RequestMapping("orders")
	private String getOrders(Model model) {
		List<Order> orders = orderService.getOrders();
		model.addAttribute("orders", orders);
		return "admin/orders";
	}
	
	@RequestMapping("show-order-details")
	public String showOrderDetails(String id, Model model) {
		Order o = 
				orderService.getOrderById(Long.parseLong(id));
		model.addAttribute("order", o);
		Map<String, String> state = new HashMap<String, String>();
		state.put(OrderState.INCOMPLETE.name(), "Initialitzed by the user");
		state.put(OrderState.COMPLETE.name(), "Completed by the user");
		state.put(OrderState.FINISHED.name(), "Order shipped");
		model.addAttribute("states", state);
		return "admin/order-detail";
	}
	
}
