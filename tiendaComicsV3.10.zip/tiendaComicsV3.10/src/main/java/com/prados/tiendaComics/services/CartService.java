package com.prados.tiendaComics.services;

import java.util.List;
import java.util.Map;

public interface CartService {

	void addProduct(long idProduct, long idUser,int quantity);
	
	List<Map<String, Object>> getUserCartProducts(long idUser);

	void deleteCartProduct(long idProduct, long idUser);

	void decreaseCartProduct(long idProduct, long idUser, Integer quantity);

	void increaseCartProduct(long idProduct, long idUser, Integer quantity);

	boolean applyPromotionalCode(String promoCode, long id) throws Exception;

	Map<String, Object> getUserCartPromoCode(long idUser);
}
