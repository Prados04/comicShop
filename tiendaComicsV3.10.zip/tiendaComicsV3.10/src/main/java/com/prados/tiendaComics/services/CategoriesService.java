package com.prados.tiendaComics.services;

import java.util.List;

import javax.validation.Valid;

import com.prados.tiendaComics.model.Category;

public interface CategoriesService {

	List<Category> getCategories();
	
	Category getCategoryById(int id);

	void deleteCategory(int id);

	void registerCategory(Category newCategory);

	void updateCategory(Category editCategory);

}
