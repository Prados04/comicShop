	package com.prados.tiendaComics.serviceSetUp;


import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.prados.tiendaComics.model.Category;
import com.prados.tiendaComics.model.Comic;
import com.prados.tiendaComics.model.ExtraUserInformation;
import com.prados.tiendaComics.model.Order;
import com.prados.tiendaComics.model.OrderProduct;
import com.prados.tiendaComics.model.PromoCode;
import com.prados.tiendaComics.model.PromoCodeState;
import com.prados.tiendaComics.model.PromoCodeType;
import com.prados.tiendaComics.model.User;
import com.prados.tiendaComics.model.orderState.OrderState;
import com.prados.tiendaComics.services.CartService;


@Service
@Transactional
public class SetUpJPAImpl implements SetUp{
	
	@PersistenceContext
	private  EntityManager entityManager;
	
	@Autowired
	private CartService cartService;

	@Override
	public void setUp() {
			
			com.prados.tiendaComics.model.SetUp registerSetUp = null;
			
			try {
				registerSetUp = 
						(com.prados.tiendaComics.model.SetUp) entityManager.createQuery("select s from SetUp as s").getSingleResult();
			} catch (Exception e) {
				System.out.println("No se encontro ningun registro de Set up, comenzamos setup...");
			}
			if ( registerSetUp == null || ! registerSetUp.isComplete() ) {
				Category novel = new Category("novel", "category classic novel");
				Category scienceFiction = new Category("Science fiction",
						"category Science fiction");
				Category adventure = new Category("adventure", "category adventure");
				entityManager.persist(novel);
				entityManager.persist(scienceFiction);
				entityManager.persist(adventure);
				
				Comic c1 = new Comic("NEGASONIC TEENAGE WARHEAD #1 (2024) #1", "NEGASONIC TEENAGE WARHEAD", "Marvel", "Andrew Wheeler", "759606211211000111",
			            "SPOTLIGHTING THE LOVEABLE PUNK! Ellie Phimister is under arrest...", "2024-11-06", 10.50);
			    c1.setLastChangeDate(new Date());
			    c1.setCategory(scienceFiction);
			    c1.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/1.jpg"));
			    c1.setSales(12);

			    Comic c2 = new Comic("KAHHORI: RESHAPER OF WORLDS (2024) #1", "RESHAPER OF WORLDS", "Marvel", "Ryan Little", "1234567891011",
			            "THE BREAKOUT CHARACTER FROM THE DISNEY+ WHAT IF...? SHOW MAKES HER COMICS DEBUT...", "2024-12-12", 19.95);
			    c2.setLastChangeDate(new Date());
			    c2.setCategory(scienceFiction);
			    c2.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/2.jpg"));
			    c2.setSales(25);

			    Comic c3 = new Comic("SPIDER-MAN: HOMEROOM HEROES (2024) #2", "HOMEROOM HEROES", "Marvel", "Arianna Florean", "1234567891011",
			            "MARVEL'S COMICS FOR KIDS CONTINUES! First, it's lights, camera, action as Peter steps up...", "2014-12-12", 9.99);
			    c3.setLastChangeDate(new Date());
			    c3.setCategory(adventure);
			    c3.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/3.jpg"));
			    c3.setSales(40);

			    Comic c4 = new Comic("Aliens Vs. Avengers (2024) #2", "Aliens Vs. Avengers", "Marvel", "Jonathan Hickman", "1234567891011",
			            "EARTH SURRENDERS?! Overwhelmed by Xenomorphs, the survivors abandon their home planet...", "2014-12-12", 5.99);
			    c4.setLastChangeDate(new Date());
			    c4.setCategory(adventure);
			    c4.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/4.jpg"));
			    c4.setSales(5);

			    Comic c5 = new Comic("Kid Venom (2024) #3", "Kid Venom", "Marvel", "T Taigami", "1234567891011",
			            "OPEN THE PORTAL! KID VENOM must return the mysterious child to her universe...", "2014-12-12", 9.99);
			    c5.setLastChangeDate(new Date());
			    c5.setCategory(novel);
			    c5.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/5.jpg"));
			    c5.setSales(18);

			    Comic c6 = new Comic("Spider-Society (2024) #4", "Spider-Society", "Marvel", "Alex Segura", "1234567891011",
			            "The Spider-Society was defeated on their very first mission and barely any of them escaped...", "2014-12-12", 11.99);
			    c6.setLastChangeDate(new Date());
			    c6.setCategory(novel);
			    c6.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/6.jpg"));
			    c6.setSales(34);
			    
				
				Comic c7 = new Comic("DC VS VAMPIRES: WORLD WAR V #4 ", "DC VS VAMPIRES: WORLD WAR V (2024)", "DC", "Matt Manning", "759604242341000111",
			            "Gorilla Grodd and Aquaman have had little luck capturing the elusive Da-mian Wayne, but a mysterious figure arrives bearing a whispered prophecy that could turn the tide of war in their favor. Elsewhere, John Constantine might well be the human resistance’s last hope…just a shame he can’t remember what it was he was meant to be doing. Enter The Spectre to help guide his way! And in the shadows, a new Batman lurks…but what’s his connection to Bruce Wayne?", "2024-11-06", 12.50);
			    c7.setLastChangeDate(new Date());
			    c7.setCategory(scienceFiction);
			    c7.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/7.jpg"));
			    c7.setSales(12);
			    
				
				Comic c8 = new Comic("BATMAN: UNCOVERED #1 ", "BATMAN", "DC", "Matt Manning", "759606211211000111",
			            "A thrilling one-shot celebrating the Caped Crusader’s most captivating covers!", "2024-11-06", 11.50);
			    c8.setLastChangeDate(new Date());
			    c8.setCategory(scienceFiction);
			    c8.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/8.jpg"));
			    c8.setSales(12);
			    
				
				Comic c9 = new Comic("BLACK LIGHTNING #1", "BLACK LIGHTNING", "DC", "Brandon Thomas", "759606211211000111",
			            "Black Lightning is back, and this time, it’s a family affair! Jefferson Pierce leads the Justice League’s new metahuman outreach initiative, helping those with powers before they can cause harm to themselves or others—but everything changes when its his own daughter, Anissa Pierce, who comes to him for help. With Thunder’s dangerous new powers and the new Masters of Disaster jeopardizing the coexistence between humans and Metas, Black Lightning is on the front lines of a culture war brewing in the suburbs of Metropolis!", "2024-11-06", 3.99);
			    c9.setLastChangeDate(new Date());
			    c9.setCategory(scienceFiction);
			    c9.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/9.jpg"));
			    c9.setSales(12);
			    
				
				Comic c10 = new Comic("ACTION COMICS #1075 ", "ACTION COMICS 2016", "DC", "Mariko Tamaki", "759606211211000111",
			            "Join the celebration as the original superhero series reaches its 1075th issue—packed with just as much Superman action as always nearly a century later! An all-star cast of talent and characters helps ring in this milestone, starting with the continuation of “Phantoms” by Mark Waid and Clayton Henry! Kal-El has traveled back in time to witness the birth of the Phantom Zone, crafted by his own father, Jor-El. Can father and son reconcile without destroying the time stream? And will the Man of Steel acquire what he needs to defeat Aethyr before his homeworld’s fate is sealed? Then, in a special Election Day story, Perry White’s mayoral ambitions come to a head…and the future of Metropolis will be forged anew with the outcome! Plus, Supergirl discovers there is more than meets the eye when it comes to the being she’s sworn to protect.", "2024-11-06", 10.50);
				c10.setLastChangeDate(new Date());
				c10.setCategory(scienceFiction);
				c10.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/10.jpg"));
				c10.setSales(12);
			    
				
				Comic c11 = new Comic("MULTIVERSUS: COLLISION DETECTED #5 ", "MULTIVERSUS: COLLISION DETECTED (2024)", "DC", "Bryan Q. Miller", "759606211211000111",
			            "With a countdown clock ticking down toward zero and skies filled with the villain-ous Devoid’s digitizing drones, Steven Universe’s Multiversus Force prepares for the worst beneath Wayne Manor. But with the Joker, the Wicked Witch, Harley Quinn, and Brainiac all under the same roof, it’s only a matter of time before an already explosive situation outright self-destructs!", "2024-11-06", 1.99);
				c11.setLastChangeDate(new Date());
				c11.setCategory(scienceFiction);
				c11.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/11.jpg"));
				c11.setSales(12);
			    
				
				Comic c12 = new Comic("LOONEY TUNES #281", "LOONEY TUNES", "DC", "Sholly Fisch", "759606211211000111",
			            "The end of the Looney Games has arrived! As Bugs Bunny presides one last time as the master of ceremonies, we head to the gym for this season’s final events, including an intense game of volleyball featuring an unexpected contender, a rousing game of table tennis, and a wrestling match for the ages!", "2024-11-06", 5.99);
				c12.setLastChangeDate(new Date());
				c12.setCategory(scienceFiction);
				c12.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/12.jpg"));
				c12.setSales(12);

			    entityManager.persist(c1);
			    entityManager.persist(c2);
			    entityManager.persist(c3);
			    entityManager.persist(c4);
			    entityManager.persist(c5);
			    entityManager.persist(c6);
			    entityManager.persist(c7);
			    entityManager.persist(c8);
			    entityManager.persist(c9);
			    entityManager.persist(c10);
			    entityManager.persist(c11);
			    entityManager.persist(c12);

			    String[] titles = {"Amazing Spider", "Fantastic Four", "Iron Man", "X-Men", "Captain America"};
			    String[] authors = {"Stan Lee", "Jack Kirby", "Steve Ditko", "John Romita", "Chris Claremont"};
			    Random rand = new Random();

			    for (int i = 7; i <= 26; i++) {
			        String title = titles[rand.nextInt(titles.length)] + " #" + i;
			        String author = authors[rand.nextInt(authors.length)];
			        double price = 5.0 + (rand.nextInt(20) * 0.5);
			        int sales = rand.nextInt(50);

			        Comic comic = new Comic(title, "Series " + i, "Marvel", author, "123456789" + i, 
			            "Description for comic #" + i, "2024-11-0" + (i % 9 + 1), price);
			        comic.setLastChangeDate(new Date());
			        comic.setCategory(novel);
			        comic.setPortraitImage(readBytesOfHomeRoute("http://localhost:8080/base_images/" + (i % 6 + 1) + ".jpg"));
			        comic.setSales(sales);

			        entityManager.persist(comic);
			    }
			    
			    String[] dcTitles = {
			    	    "DC VS VAMPIRES: WORLD WAR V", "BATMAN: THE DARK KNIGHT", "JUSTICE LEAGUE: WAR", "SUPERMAN: METAMORPHOSIS",
			    	    "THE FLASH: REBIRTH", "GREEN LANTERN: SECTOR 2814", "WONDER WOMAN: GODDESS OF WAR", "AQUAMAN: KING OF ATLANTIS",
			    	    "GREEN ARROW: THE LONG BOW HUNTERS", "SHAZAM: THE NEW 52", "ROBIN: YEAR ONE", "JOKER: KILLER CLOWN", 
			    	    "BLACK LIGHTNING: THE KILLING ZONE", "CYBORG: METAMORPHOSIS", "HARLEY QUINN: BIRDS OF PREY", 
			    	    "TEEN TITANS: YOUNG JUSTICE", "JUSTICE LEAGUE DARK: THE HELLBLAZER", "CATWOMAN: FERAL HEART",
			    	    "BATGIRL: KILLING JOKE", "THE SANDMAN: THE DREAMING"
			    	};

			    	String[] dcAuthors = {
			    	    "Scott Snyder", "Tom King", "Grant Morrison", "Brian Michael Bendis", "Mark Waid", "Geoff Johns", "James Tynion IV",
			    	    "Alan Moore", "Frank Miller", "John Byrne", "Gail Simone", "Robert Venditti", "Joshua Williamson", "Paul Dini",
			    	    "Tom Taylor", "Dan Jurgens", "Geoff Johns", "Mark Millar", "Chuck Dixon", "Jeff Lemire"
			    	};

			    	Random rand2 = new Random();
			    	Date currentDate = new Date();  // for LastChangeDate

			    	for (int i = 27; i <= 46; i++) { // Generating comics 27 to 46
			    	    String title = dcTitles[rand2.nextInt(dcTitles.length)] + " #" + i;
			    	    String author = dcAuthors[rand2.nextInt(dcAuthors.length)];
			    	    double price = 4.99 + (rand2.nextInt(15) * 0.5);  // Random price between $4.99 to $14.99
			    	    int sales = rand2.nextInt(50) + 10;  // Random sales between 10 to 59

			    	    // Select image from 7 to 12 (modulo range of 7-12)
			    	    String imagePath = "http://localhost:8080/base_images/" + (7 + (i % 6)) + ".jpg"; // This will cycle through images 7-12

			    	    Comic newComic = new Comic(title, title, "DC", author, "759604242341000" + i,
			    	            "Description for comic #" + i, "2024-11-" + (12), price);
			    	    newComic.setLastChangeDate(currentDate);
			    	    newComic.setCategory(novel);
			    	    newComic.setPortraitImage(readBytesOfHomeRoute(imagePath));
			    	    newComic.setSales(sales);

			    	    entityManager.persist(newComic);  // Save the new comic to the database
			    	}
			    	
			    	String[] otherEditorialTitles = {
			    		    "The Walking Dead", "Saga", "Sandman", "Y: The Last Man", "Invincible", "The Boys", 
			    		    "Locke & Key", "Preacher", "Maus", "Hellboy", "Bone", "Fables", 
			    		    "100 Bullets", "The Crow", "V for Vendetta", "Judge Dredd", "Sin City", "Ghost World", "Watchmen"
			    		};

			    		String[] otherEditorialAuthors = {
			    		    "Robert Kirkman", "Brian K. Vaughan", "Neil Gaiman", "Brian Wood", "Robert Kirkman", 
			    		    "Garth Ennis", "Joe Hill", "Garth Ennis", "Art Spiegelman", "Mike Mignola", "Jeff Smith", 
			    		    "Bill Willingham", "Brian Azzarello", "James O'Barr", "Alan Moore", "John Wagner", "Frank Miller", 
			    		    "Daniel Clowes", "Alan Moore"
			    		};

			    		Random rand3 = new Random();

			    		for (int i = 47; i <= 66; i++) { // Generating comics 47 to 66
			    		    String title = otherEditorialTitles[rand3.nextInt(otherEditorialTitles.length)] + " #" + i;
			    		    String author = otherEditorialAuthors[rand3.nextInt(otherEditorialAuthors.length)];
			    		    double price = 4.99 + (rand3.nextInt(15) * 0.5);  // Random price between $4.99 to $14.99
			    		    int sales = rand3.nextInt(50) + 10;  // Random sales between 10 to 59

			    		    // Select image from 13 to 18 (modulo range of 13-18)
			    		    String imagePath = "http://localhost:8080/base_images/" + (13 + (i % 6)) + ".jpg"; // This will cycle through images 13-18

			    		    Comic newComic = new Comic(title, title, "Other Editorial", author, "759604242341000" + i,
			    		            "Description for comic #" + i, "2023-11-" + (15), price);
			    		    newComic.setLastChangeDate(currentDate);
			    		    newComic.setCategory(novel);
			    		    newComic.setPortraitImage(readBytesOfHomeRoute(imagePath));
			    		    newComic.setSales(sales);

			    		    entityManager.persist(newComic);
			    		}
			    
				
				User u1 = new User("Jorge04", "jorge@gmail.com", "123456","Jorge","Gonzalez","999999999");
				User u2 = new User("Jaimito08", "jaime@gmail.com", "123456","Jaime","Rodriguez","111111111");
				User u3 = new User("Jaavier0464", "javi@gmail.com", "123456","Javier","Muñoz","444444444");
				entityManager.persist(u1);
				entityManager.persist(u2);
				entityManager.persist(u3);
				
				cartService.addProduct(c1.getId(), u1.getId(), 5);
				cartService.addProduct(c2.getId(), u1.getId(), 2);
				
				cartService.addProduct(c3.getId(), u2.getId(), 3);
				cartService.addProduct(c2.getId(), u2.getId(), 4);
				
				PromoCode promo01 = new PromoCode();
				promo01.setDiscount(10);
				promo01.setPromoCodeName("10Percentage");
				promo01.setPromoCodeType(PromoCodeType.PERCENTAGE.name());
				promo01.setUsages(10000);
				promo01.setCodeState(PromoCodeState.VALID.name());
				entityManager.persist(promo01);
				
				PromoCode promo02 = new PromoCode();
				promo02.setDiscount(10);
				promo02.setPromoCodeName("10Discount");
				promo02.setPromoCodeType(PromoCodeType.STATIC_PRICE.name());
				promo02.setUsages(10000);
				promo02.setCodeState(PromoCodeState.VALID.name());
				entityManager.persist(promo02);
				
				PromoCode promo03 = new PromoCode();
				promo03.setDiscount(0);
				promo03.setPromoCodeName("FreeShipping");
				promo03.setPromoCodeType(PromoCodeType.FREE_SHIPPING.name());
				promo03.setUsages(10000);
				promo03.setCodeState(PromoCodeState.VALID.name());
				entityManager.persist(promo03);
				
				Order o1 = new Order();
				o1.setAddress("Calle prados, 7");
				o1.setCity("Madrid");
				o1.setCountry("Spain");
				o1.setProvince("Madrid");
				o1.setFullName("Sergio Prados");
				o1.setPhoneNumber("999999999");
				o1.setZipCode("28003");
				o1.setCardCVV("444");
				o1.setCardExpirationDate("10/05");
				o1.setCardType("VISA");
				o1.setExtraShippmentInformation("Without extra info");
				o1.setCardNumber("444444444444");
				o1.setUser(u1);
				o1.setCardHolder("Sergio Prados");
				o1.setState(OrderState.FINISHED.name());
				entityManager.persist(o1);
				OrderProduct op1= new OrderProduct();
				op1.setOrder(o1);
				op1.setComic(c2);
				op1.setQuantity(2);
				entityManager.persist(op1);
				
				Order o2 = new Order();
				o2.setAddress("Calle rodroguez, 4");
				o2.setCity("Granada");
				o2.setProvince("Andalucia");
				o2.setCountry("Spain");
				o2.setFullName("Martin Prados");
				o2.setPhoneNumber("444444444");
				o2.setZipCode("28004");
				o2.setCardCVV("564");
				o2.setCardExpirationDate("05/12");
				o2.setCardType("MASTERCARD");
				o2.setExtraShippmentInformation("Without extra info");
				o2.setCardNumber("123456789123");
				o2.setUser(u2);
				o2.setCardHolder("Martin Prados");
				o2.setState(OrderState.FINISHED.name());
				entityManager.persist(o2);
				OrderProduct op2= new OrderProduct();
				op2.setOrder(o2);
				op2.setComic(c1);
				op2.setQuantity(3);
				entityManager.persist(op2);
				
				
				com.prados.tiendaComics.model.SetUp setup = new com.prados.tiendaComics.model.SetUp();
				setup.setComplete(true);
				entityManager.persist(setup);
			}
	
	}
	
	private byte[] readBytesOfHomeRoute(String routeHome) {
		byte[] info = null;
		try {
			URL url= new URL(routeHome);
			info = IOUtils.toByteArray(url);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Icant read the route");
		}
		return info;
	}
	
	
}
