package com.prados.tiendaComics.servicesJPAImpl;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.internal.NativeQueryImpl;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.prados.tiendaComics.constantsSQL.ConstantsSQL;
import com.prados.tiendaComics.model.Category;
import com.prados.tiendaComics.model.Comic;
import com.prados.tiendaComics.services.ComicsService;

@Service
@Transactional
public class ServiceComicsJPAImpl implements ComicsService{

	@PersistenceContext
	private  EntityManager entityManager;
	
	@Override
	public void registerComic(Comic c) {
		Category cat = entityManager.find(Category.class, c.getIdCategory());
		c.setCategory(cat);;	
		entityManager.persist(c);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Comic> getComics() {
		return entityManager.createQuery("select c from Comic c").getResultList();
	}

	@Override
	public void deleteComic(Long id) {
		Comic l = entityManager.find(Comic.class, id);
		entityManager.remove(l);
	}

	@Override
	public Comic getComicById(Long id) {
		return entityManager.find(Comic.class, id);
	}

	@Override
	public void updateComic(Comic c) {
		entityManager.merge(c);
	}

	@Override
	public Map<String, Object> getComicViewDetailsById(Long id) {
		Query query = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_COMIC_DETAILS);
		query.setParameter("id", id);
		NativeQueryImpl nativeQuery = (NativeQueryImpl)query;
		nativeQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
		return (Map<String, Object>)nativeQuery.getSingleResult();
	}

	@Override
	public List<Map<String, Object>> getComicsForList() {
		Query query = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_COMICS_LIST);
		NativeQueryImpl nativeQuery = (NativeQueryImpl)query;
		nativeQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
		return nativeQuery.getResultList();
	}
	
	@Override
	public List<Map<String, Object>> getComicsForList(String title, int start, String editorial, String extra_things) {
	    Query query = entityManager.createNativeQuery("");
	    if (extra_things.equalsIgnoreCase("hottest")){
	    	System.err.println("Entra aqui");
	    	query = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_COMICS_ORDER_BY_SALES);
	    }else if(editorial.equalsIgnoreCase("others")) {
	        query = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_COMICS_LIST_EXCLUDING_EDITORIALS);
	    } else {
	        query = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_COMICS_LIST_BY_TITLE_AND_EDITORIAL);
	        query.setParameter("editorial", "%" + editorial + "%");
	    }
	    query.setParameter("title", "%" + title + "%");
	    query.setParameter("start", start);
	    NativeQueryImpl nativeQuery = (NativeQueryImpl)query;
	    nativeQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
	    return nativeQuery.getResultList();
	}

	@Override
	public List<Comic> getComics(String title) {
		return entityManager.createQuery("select c from Comic c where c.title like :title").setParameter("title", "%" + title + "%").getResultList();
	}

	@Override
	public List<Comic> getComics(String title, int start, int resultsPerPage) {
		return entityManager.createQuery("select c from Comic c where c.title like :title").setParameter("title", "%" + title + "%").setFirstResult(start).setMaxResults(resultsPerPage).getResultList();

	}

	@Override
	public int getTotalComics() {
		Query q = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_TOTAL_COMICS);
		return Integer.parseInt(q.getSingleResult().toString());
	}

	@Override
	public int getTotalComics(String title, String editorial, String extra_things) {
		Query q = entityManager.createNativeQuery("");
		if(extra_things.equalsIgnoreCase("hottest")) {
			q = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_TOTAL_COMICS_BY_TITLE);
		}else if(editorial.equalsIgnoreCase("others")) {
			q = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_TOTAL_COMICS_BY_EXCLUDING_EDITORIALS);
		}else {
			q = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_TOTAL_COMICS_BY_TITLE_AND_EDITORIALS);
			q.setParameter("editorial", "%"+editorial+"%");
		}
		q.setParameter("title", "%"+title+"%");
		return Integer.parseInt(q.getSingleResult().toString());
	}

	@Override
	public int getTotalComics(String title) {
		Query q = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_TOTAL_COMICS_BY_TITLE);
		q.setParameter("title", "%"+title+"%");
		return Integer.parseInt(q.getSingleResult().toString());
	}

}
