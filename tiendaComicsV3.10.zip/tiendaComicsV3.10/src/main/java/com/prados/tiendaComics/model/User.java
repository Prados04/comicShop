package com.prados.tiendaComics.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
@Table(name = "table_users")
public class User {

    @Id
    @GeneratedValue
    private Long id;

    @NotEmpty(message = "Username can't be empty")
    @Size(min = 3, max = 40, message = "Username needs to have between 3 and 40 characters")
    @Column(unique = true, nullable = false, length = 40)
    private String username;

    @NotEmpty(message = "Email can't be empty")
    @Email(message = "Email should be valid")
    @Column(unique = true, nullable = false, length = 100)
    private String email;

    @NotEmpty(message = "Password can't be empty")
    @Size(min = 6, message = "Password must have at least 6 characters")
    private String pass;

    @NotEmpty(message = "Name can't be empty")
    @Size(min = 2, max = 50, message = "Name needs to have between 2 and 50 characters")
    private String name;

    @Size(min = 2, max = 50, message = "Second Name can't exceed 50 characters")
    private String secondName;

    @Pattern(regexp = "^[0-9]{7,15}$", message = "Telephone number must be numeric and between 7 to 15 digits")
    @Column(unique = true, nullable = true, length = 15)
    private String telNumber;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    private Cart cart;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "extra_user_info_id", referencedColumnName = "id")
    private ExtraUserInformation extraUserInformation;
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Order> orders = new ArrayList<>();
	
	public User() {
		super();
		this.extraUserInformation = new ExtraUserInformation();
	}
	
	public User(String username, String email, String pass, String name, String secondName, String telNumber) {
		super();
		this.username = username;
		this.email = email;
		this.pass = pass;
		this.name = name;
		this.secondName = secondName;
		this.telNumber = telNumber;
		this.extraUserInformation = new ExtraUserInformation();
	}
	
    public void addOrder(Order order) {
        orders.add(order);
        order.setUser(this);
    }

    public void removeOrder(Order order) {
        orders.remove(order);
        order.setUser(null);
    }

    // Ensure this method is present and correctly implemented
    public void setOrders(List<Order> orders) {
        this.orders.clear();
        if (orders != null) {
            for (Order order : orders) {
                addOrder(order);
            }
        }
    }
    
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public String getTelNumber() {
		return telNumber;
	}
	public void setTelNumber(String telNumber) {
		this.telNumber = telNumber;
	}
	
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public ExtraUserInformation getExtraUserInformation() {
		return extraUserInformation;
	}
	public void setExtraUserInformation(ExtraUserInformation extraUserInformation) {
		this.extraUserInformation = extraUserInformation;
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", email=" + email + ", pass=" + pass + ", name=" + name + ", secondName="
				+ secondName + ", telNumber=" + telNumber + ", id=" + id + "]";
	}
	
}
