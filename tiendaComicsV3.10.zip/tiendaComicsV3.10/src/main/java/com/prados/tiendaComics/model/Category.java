package com.prados.tiendaComics.model;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "table_categories")
public class Category {

    @Id
    @GeneratedValue
    private int id;

    @NotEmpty(message = "Name can't be empty")
    @Size(min = 3, max = 40, message = "Name needs to have between 3 and 40 characters")
    @Column(length = 40)
    private String name;

    @Size(max = 255, message = "Description can't exceed 255 characters")
    @Column(length = 255)
    private String description;

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comic> comics = new ArrayList<>();

    // Constructors

    public Category() {
        super();
    }

    public Category(String name, String description) {
        super();
        this.name = name;
        this.description = description;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Comic> getComics() {
        return comics;
    }

    public void setComics(List<Comic> comics) {
        this.comics.clear();
        if (comics != null) {
            for (Comic comic : comics) {
                addComic(comic);
            }
        }
    }

    // Helper methods to manage the relationship

    public void addComic(Comic comic) {
        comics.add(comic);
        comic.setCategory(this);
    }

    public void removeComic(Comic comic) {
        comics.remove(comic);
        comic.setCategory(null);
    }

    @Override
    public String toString() {
        return "Category [name=" + name + ", description=" + description + ", id=" + id + "]";
    }
}