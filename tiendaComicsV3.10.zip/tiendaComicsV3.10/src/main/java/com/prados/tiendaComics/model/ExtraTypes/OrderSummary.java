package com.prados.tiendaComics.model.ExtraTypes;

import java.util.List;
import java.util.Map;

public class OrderSummary {
	
	private List<Map<String, Object>> comics;
	private String fullName;
	private String phoneNumber;
	private String address;
	private String zipCode;
	private String province;
	private String city;
	private String country;
	private String cardType;
	private String cardNumber;
	private String cardHolder;
	private String cardExpirationDate;
	private String extraShippmentInformation;
	private String cardCVV;
	
    private Double productsPrice;
    private Double shippingPrice;
    private Double discountAmount;
    private Double taxesPrice;
    private Double totalPrice;
	
	public List<Map<String, Object>> getComics() {
		return comics;
	}
	public void setComics(List<Map<String, Object>> comics) {
		this.comics = comics;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getZipCode() {
		return zipCode;
	}
	public String getExtraShippmentInformation() {
		return extraShippmentInformation;
	}
	public void setExtraShippmentInformation(String extraShippmentInformation) {
		this.extraShippmentInformation = extraShippmentInformation;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardHolder() {
		return cardHolder;
	}
	public void setCardHolder(String cardHolder) {
		this.cardHolder = cardHolder;
	}
	public String getCardExpirationDate() {
		return cardExpirationDate;
	}
	public void setCardExpirationDate(String cardExpirationDate) {
		this.cardExpirationDate = cardExpirationDate;
	}
	public String getCardCVV() {
		return cardCVV;
	}
	public void setCardCVV(String cardCVV) {
		this.cardCVV = cardCVV;
	}
	public Double getProductsPrice() {
		return productsPrice;
	}
	public void setProductsPrice(Double productsPrice) {
		this.productsPrice = productsPrice;
	}
	public Double getShippingPrice() {
		return shippingPrice;
	}
	public void setShippingPrice(Double shippingPrice) {
		this.shippingPrice = shippingPrice;
	}
	public Double getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(Double discountAmount) {
		this.discountAmount = discountAmount;
	}
	public Double getTaxesPrice() {
		return taxesPrice;
	}
	public void setTaxesPrice(Double taxesPrice) {
		this.taxesPrice = taxesPrice;
	}
	public Double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	
	
}
