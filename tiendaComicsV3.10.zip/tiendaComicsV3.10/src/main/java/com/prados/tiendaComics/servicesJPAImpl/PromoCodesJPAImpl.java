package com.prados.tiendaComics.servicesJPAImpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.prados.tiendaComics.model.PromoCode;
import com.prados.tiendaComics.services.PromoCodesService;

@Service
@Transactional
public class PromoCodesJPAImpl implements PromoCodesService{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<PromoCode> getPromoCodes() {
		System.err.println("Get promo code");
		return entityManager.createQuery("select pc from PromoCode pc").getResultList();
	}

	@Override
	public void deletePromoCode(int id) {
		PromoCode pc = entityManager.find(PromoCode.class, id);
		entityManager.remove(pc);
	}

	@Override
	public void registerPromoCode(PromoCode newPromoCode) {
		entityManager.persist(newPromoCode);
	}

	@Override
	public PromoCode getPromoCodeById(int id) {
		return entityManager.find(PromoCode.class, id);
	}

	@Override
	public void updatePromoCode(PromoCode editPromoCode) {
		entityManager.merge(editPromoCode);
	}

}
