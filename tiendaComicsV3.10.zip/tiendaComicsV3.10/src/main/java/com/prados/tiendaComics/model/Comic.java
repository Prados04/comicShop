package com.prados.tiendaComics.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.web.multipart.MultipartFile;


@Entity
@Table(name= "table_comics")
public class Comic {

	@Lob
	@Column(name= "portrait_image")
	private byte[] portraitImage;
	
	@Transient
	private int idCategory;
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;
    
    @OneToMany(mappedBy = "comic", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OrderProduct> orderProducts = new ArrayList<>();
    
    @OneToMany(mappedBy = "comic", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ProductCart> productCarts = new ArrayList<>();
	
	@Size(min = 3, max = 40, message = "title needs to have between 3 and 40 characters")
	@NotEmpty(message = "Title can't be empty")
	@Pattern(regexp = "^[a-zA-Z0-9áéíóúñ:&/#\\s,\\.\\-!?@&%\\+=;\"'()\\[\\]{}<>|^$*_~`]*$", message = "Title can only contain alphanumeric characters and spaces, as well as common punctuation marks.")
	@Column(length = 120)
	private String title;

	@Size(min = 2, max = 40, message = "Editorial needs to have between 2 and 40 characters")
	@NotEmpty(message = "Editorial can't be empty")
	@Pattern(regexp = "^[a-zA-Z0-9áéíóúñ,\\s]*$", message = "Editorial can only contain alphanumeric characters and spaces")
	private String editorial;

	@Size(min = 3, max = 40, message = "Author needs to have between 3 and 40 characters")
	@NotEmpty(message = "Author can't be empty")
	@Pattern(regexp = "^[a-zA-Záéíóúñ,.'\\s]*$", message = "Author can only contain alphabetic characters and spaces")
	private String author;

	@Size(min = 10, max = 30, message = "ISBN needs to have between 10 and 30 characters")
	@NotEmpty(message = "ISBN can't be empty")
	@Pattern(regexp = "^[0-9-]*$", message = "ISBN can only contain numbers and hyphens")
	private String isbn;

	@Size(max = 1200, message = "Description can't exceed 1200 characters")
	private String description;
	
	@Pattern(regexp = "^(\\d{4}-\\d{2}-\\d{2})$", message = "Release date must be in the format YYYY-MM-DD")
	@NotEmpty(message = "Release date can't be empty")
	private String releaseDate;
	
	@Size(max = 50, message = "Series can't exceed 50 characters")
	@Pattern(regexp = "^[a-zA-Z0-9áéíóú_ñ&,:/#\\s)(,\\.\\-!?]*$", message = "Series can only contain alphanumeric characters and common punctuation")
	@NotEmpty(message = "Release date can't be empty")
	@Column(length = 50)
	private String series;

	@NotNull(message = "Price can't be null")
	@DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than 0")
	private Double price;
	
	@Transient
	private MultipartFile uploadFile;
	
	private Date lastChangeDate;
	
	private long sales;
	
	@Id
	@GeneratedValue
	private Long id;
	
	public Comic() {
		super();
	}
	
	public Comic(String title,String series, String editorial, String author, String isbn, String description, String releaseDate,
			Double price) {
		super();
		this.title = title;
		this.series = series;
		this.editorial = editorial;
		this.author = author;
		this.isbn = isbn;
		this.description = description;
		this.releaseDate = releaseDate;
		this.price = price;
	}
	
    public void addProductCart(ProductCart productCart) {
        productCarts.add(productCart);
        productCart.setComic(this);
    }

    public void removeProductCart(ProductCart productCart) {
        productCarts.remove(productCart);
        productCart.setComic(null);
    }

    public void addOrderProduct(OrderProduct orderProduct) {
        orderProducts.add(orderProduct);
        orderProduct.setComic(this);
    }

    public void removeOrderProduct(OrderProduct orderProduct) {
        orderProducts.remove(orderProduct);
        orderProduct.setComic(null);
    }
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}
	public long getSales() {
		return sales;
	}
	public void setSales(long sales) {
		this.sales = sales;
	}
	public String getEditorial() {
		return editorial;
	}
	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	

	public MultipartFile getUploadFile() {
		return uploadFile;
	}

	public void setUploadFile(MultipartFile uploadFile) {
		this.uploadFile = uploadFile;
	}

	public Date getLastChangeDate() {
		return lastChangeDate;
	}

	public void setLastChangeDate(Date lastChangeDate) {
		this.lastChangeDate = lastChangeDate;
	}

	public int getIdCategory() {
		return idCategory;
	}

	public void setIdCategory(int idCategorie) {
		this.idCategory = idCategorie;
	}

	public Category getCategory() {
		return category;
	}

    public void setCategory(Category category) {
        if (this.category != null) {
            this.category.getComics().remove(this);
        }
        this.category = category;
        if (category != null) {
            category.getComics().add(this);
        }
    }

	public byte[] getPortraitImage() {
		return portraitImage;
	}

	public void setPortraitImage(byte[] bs) {
		this.portraitImage = bs;
	}
	
	
	
}
