package com.prados.tiendaComics.controllers.image;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prados.tiendaComics.services.ComicsService;

@Controller
public class showProductImage {

		@Autowired
		private ComicsService comicsService;
		
		@RequestMapping("show_image")
		public void showImage(String id, HttpServletResponse response) throws IOException {
			byte[] info = comicsService.getComicById(Long.parseLong(id)).getPortraitImage();
					if (info == null) {
						return;
					}
					response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
					response.getOutputStream().write(info);
					response.getOutputStream().close();
		}
}
