package com.prados.tiendaComics.servicesREST;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.prados.tiendaComics.model.User;
import com.prados.tiendaComics.services.CartService;
import com.prados.tiendaComics.validationConstants.ValidationConstants;

@RestController
public class RESTServiceCart {
	
	@Autowired
	private CartService cartService;
	
	@RequestMapping("apply-promo-code")
	public String applyPromoCode(String promoCode,HttpServletRequest request) {
		User u = (User) request.getSession().getAttribute("user");
		try {
			if (cartService.applyPromotionalCode(promoCode, u.getId())) {
				return "ok";
			}else {
				return "no-ok";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "no-ok";
	}
	
	private boolean validateFields(Integer quantity) {
		Pattern patternQuantity = Pattern.compile(ValidationConstants.regExpQuantity, Pattern.CASE_INSENSITIVE);
		Matcher matchesQuantity = patternQuantity.matcher(quantity.toString());
		if (matchesQuantity.matches()) {
			return true;
		}
		System.err.println("false");
		return false;

	}
	
	@RequestMapping("add-product-cart")
	public String addProductToCart(@RequestParam("id") Integer idProduct, @RequestParam("quantity") Integer quantity, HttpServletRequest request) {
		if (validateFields(quantity)) {
			User user = (User) request.getSession().getAttribute("user");
			cartService.addProduct(idProduct, user.getId(), quantity);
			return "ok";
		}else {
			return "incorrect quantity from server side";
		}
	}
	
	@RequestMapping("get-cart-products")
	public List<Map<String, Object>> getCartProducts(HttpServletRequest request) {	
		return cartService.getUserCartProducts
			( ((User) request.getSession().getAttribute("user")).getId() );
	}
	
	@RequestMapping("increase-cart-products")
	public String increaseCartProducts(@RequestParam("id") long idProduct, @RequestParam("quantity") Integer quantity,
            HttpServletRequest request) {
		if (validateFields(quantity)) {
			User user = (User) request.getSession().getAttribute("user");
			cartService.increaseCartProduct(idProduct, user.getId(), quantity);
			return "ok";
		}else {
			return "incorrect quantity from server side";
		}

	}
	
	@RequestMapping("decrease-cart-products")
	public String decreaseCartProducts(@RequestParam("id") long idProduct, @RequestParam("quantity") Integer quantity,
            HttpServletRequest request) {
		if (validateFields(quantity)) {
			User user = (User) request.getSession().getAttribute("user");
			cartService.decreaseCartProduct(idProduct, user.getId(), quantity);
			return "ok";
		}else {
			return "incorrect quantity from server side";
		}
	}
	
	@RequestMapping("delete-cart-products")
	public String deleteCartProducts(@RequestParam("id") long id, HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		cartService.deleteCartProduct(id, user.getId());
		return "ok";
	}
	
	@RequestMapping("get-cart-promo-code")
	public Map<String, Object> getPromoCode(HttpServletRequest request){
		return cartService.getUserCartPromoCode
				( ((User) request.getSession().getAttribute("user")).getId() );
	}
	
	
	
	
	
}
