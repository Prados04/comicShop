package com.prados.tiendaComics.servicesJPAImpl;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prados.tiendaComics.constantsSQL.ConstantsSQL;
import com.prados.tiendaComics.model.Cart;
import com.prados.tiendaComics.model.Order;
import com.prados.tiendaComics.model.OrderPaymentSummary;
import com.prados.tiendaComics.model.OrderProduct;
import com.prados.tiendaComics.model.ProductCart;
import com.prados.tiendaComics.model.PromoCode;
import com.prados.tiendaComics.model.PromoCodeState;
import com.prados.tiendaComics.model.User;
import com.prados.tiendaComics.model.ExtraTypes.OrderSummary;
import com.prados.tiendaComics.model.orderState.OrderState;
import com.prados.tiendaComics.services.CartService;
import com.prados.tiendaComics.services.OrderService;

@Service
@Transactional
public class ServiceOrdersJPAImpl implements OrderService{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private CartService cartService;

	private Order getActualOrder(long idUser) throws Exception {
		User user = entityManager.find(User.class, idUser);
		Object orderInProcess = null;
		
		@SuppressWarnings("unchecked")
		List<Order> queryResult =  entityManager.createQuery(
				"select o from Order o where o.state = :state and o.user.id = :user_id"
				).setParameter("state", OrderState.INCOMPLETE.name()).
		setParameter("user_id", idUser).getResultList();
		
		if(queryResult.size() == 1) {
			orderInProcess = queryResult.get(0);
		}else if (queryResult.size() > 1) {
			throw new Exception("Something went wrong, more than 1 incomplete order for the same User");
		}
		
		Order order = null;
		if ( orderInProcess != null ) {
			order = (Order) orderInProcess;
		}else {
			order = new Order();
			order.setState(OrderState.INCOMPLETE.name());
			order.setUser(user);
		}
		return order;
	}
	
	@Override
	public void processStep01(String fullName, String phoneNumber, String address, String zipCode, String province,
			String city, String country, long idUser) {
		try {
			Order o = getActualOrder(idUser);
			o.setFullName(fullName);
			o.setPhoneNumber(phoneNumber);
			o.setAddress(address);
			o.setZipCode(zipCode);
			o.setProvince(province);
			o.setCity(city);
			o.setCountry(country);
			entityManager.merge(o);
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Something went wrong getting the actual order");
		}
		
	}
	
	@Override
	public void processStep02(String extraShippmentInformation, String timesReadComics, long idUser) {
		try {
			Order o = getActualOrder(idUser);
			User u = entityManager.find(User.class, idUser);
			o.setExtraShippmentInformation(extraShippmentInformation);
			u.getExtraUserInformation().setTimesReadComics(timesReadComics);	
			entityManager.merge(o);
			entityManager.merge(u);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Something went wrong getting the actual order");
		}
	}
	
	@Override
	public void processStep03(String cardType, String cardNumber, String cardHolder, String cardExpirationDate,
			String cardCVV, long idUser) {
		try {
			Order o = getActualOrder(idUser);
			o.setCardHolder(cardHolder);
			o.setCardNumber(cardNumber);
			o.setCardType(cardType);
			o.setCardCVV(cardCVV);
			o.setCardExpirationDate(cardExpirationDate);
			
			entityManager.merge(o);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public OrderSummary getOrderSummary(long idUser) {
		OrderSummary orderSummary = new OrderSummary();
		try {
			Order o = getActualOrder(idUser);
			orderSummary.setFullName(o.getFullName());
			orderSummary.setPhoneNumber(o.getPhoneNumber());
			orderSummary.setZipCode(o.getZipCode());
			orderSummary.setAddress(o.getAddress());
			orderSummary.setProvince(o.getProvince());
			orderSummary.setCardType(o.getCardType());
			orderSummary.setCity(o.getCity());
			orderSummary.setCountry(o.getCountry());
			orderSummary.setCardNumber(o.getCardNumber());
			orderSummary.setCardHolder(o.getCardHolder());
			orderSummary.setCardCVV(o.getCardCVV());
			orderSummary.setCardExpirationDate(o.getCardExpirationDate());
			orderSummary.setExtraShippmentInformation(o.getExtraShippmentInformation());
			orderSummary.setProductsPrice(o.getOrderPaymentSummary().getProductsPrice());
			orderSummary.setShippingPrice(o.getOrderPaymentSummary().getShippingPrice());
			orderSummary.setDiscountAmount(o.getOrderPaymentSummary().getDiscountAmount());
			orderSummary.setTaxesPrice(o.getOrderPaymentSummary().getTaxesPrice());
			orderSummary.setTotalPrice(o.getOrderPaymentSummary().getTotalPrice());
			orderSummary.setComics(cartService.getUserCartProducts(idUser));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return orderSummary;
	}

	@Override
	public void confirmOrder(long idUser) {
		try {
			Order o = getActualOrder(idUser);
			User user = entityManager.find(User.class, idUser);
			Cart cart = user.getCart();
			if ( cart != null && cart.getProductCarts().size() > 0) {
				for (ProductCart pc : cart.getProductCarts()) {
					OrderProduct op  = new OrderProduct();
					op.setQuantity(pc.getQuantity());
					op.setComic(pc.getComic());
					o.getProductsOrder().add(op);
					op.setOrder(o);
					pc.getComic().setSales(pc.getComic().getSales()+1);
					entityManager.merge(pc.getComic());
					entityManager.persist(op);
				}
			}
			Query query = 
					entityManager.createNativeQuery(
							ConstantsSQL.SQL_DELETE_CART_PRODUCT);
			query.setParameter("cart_id", cart.getId());
			query.executeUpdate();
			o.setState(OrderState.COMPLETE.name());
			cart.setPromoCode(null);
			entityManager.merge(cart);
			entityManager.merge(o);
		} catch (Exception e) {


			e.printStackTrace();
		}
		
	}

	@Override
	public List<Order> getOrders() {
		List<Order> orders = entityManager.createQuery("select ord from Order ord order by ord.id desc", Order.class).getResultList();
		return orders;
	}

	@Override
	public Order getOrderById(long idOrder) {
		return entityManager.find(Order.class, idOrder);
	}

	@Override
	public void updateOrderState(long id, String state) {
		Order o = entityManager.find(Order.class, id);
		o.setState(state);
		entityManager.merge(o);
	}

	@Override
	public void processStep00(double productsPrice, double taxesPrice, double shippingPrice, double discountAmount,
			double totalPrice, long idUser) {
		try {
			OrderPaymentSummary orderPaymentSummary = new OrderPaymentSummary(productsPrice, taxesPrice, shippingPrice, discountAmount, totalPrice);
			Order o = getActualOrder(idUser);
			o.setOrderPaymentSummary(orderPaymentSummary);
			entityManager.merge(o);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Something went wrong getting the actual order");
		}
		
	}
}
