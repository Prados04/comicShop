package com.prados.tiendaComics.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prados.tiendaComics.model.User;
import com.prados.tiendaComics.services.UsersService;
import com.prados.tiendaComics.services.UsersService;

@Controller
@RequestMapping("admin/")
public class UsersController {
	@Autowired
	private UsersService serviceUsers;
	
	@RequestMapping("users")
	public String getUsers(Model model) {
		List<User> users =  serviceUsers.getUsers();
		model.addAttribute("users",users);
		return "admin/users";
	}
	
	@RequestMapping("users-delete")
	public String deleteUser(String id, Model model) {
		serviceUsers.deleteUser(Long.parseLong(id));
		return getUsers(model);
	}
	
	@RequestMapping("users-new")
	public String newUser(Model model) {
		System.err.println("New user");
		User c = new User();
		model.addAttribute("newUser", c);
		model.addAttribute("users", serviceUsers.getUsers());
		return "admin/new-user";
	}
	
	@RequestMapping("users-save")
	public String saveNewUser(@ModelAttribute("newUser") @Valid User newUser, BindingResult br, Model model, HttpServletRequest  request ) {
		if (br.hasErrors()) {
			model.addAttribute("users", serviceUsers.getUsers());
			return "admin/new-user";
		}
		serviceUsers.registerUser(newUser);
		return getUsers(model);
	}
	
	@RequestMapping("users-edit")
	public String editUser(String id, Model model) {
		User u=serviceUsers.getUserById(Long.parseLong(id));
		model.addAttribute("editUser", u);
		model.addAttribute("users", serviceUsers.getUsers());
		return "admin/edit-user";
	}
	
	@RequestMapping("users-save-changes")
	public String saveChangesUser(@ModelAttribute("editUser") @Valid User editUser, BindingResult br, Model model, HttpServletRequest request) {
		if (br.hasErrors()) {
			return "admin/edit-user";
		}
		serviceUsers.updateUser(editUser);
		return getUsers(model);
	}
}
