package com.prados.tiendaComics.services;

import java.util.List;

import javax.validation.Valid;

import com.prados.tiendaComics.model.PromoCode;

public interface PromoCodesService {

	List<PromoCode> getPromoCodes();

	void deletePromoCode(int id);

	void registerPromoCode(PromoCode newPromoCode);

	PromoCode getPromoCodeById(int id);

	void updatePromoCode(PromoCode editPromoCode);

}
