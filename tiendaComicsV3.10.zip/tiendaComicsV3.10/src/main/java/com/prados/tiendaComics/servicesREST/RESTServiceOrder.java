package com.prados.tiendaComics.servicesREST;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prados.tiendaComics.model.User;
import com.prados.tiendaComics.model.ExtraTypes.OrderSummary;
import com.prados.tiendaComics.services.OrderService;
import com.prados.tiendaComics.validationConstants.ValidationConstants;

@RestController
public class RESTServiceOrder {

	
	@Autowired
	private OrderService orderService;
	
	@RequestMapping("place-order-step-00")
	public String placeOrderStep00(Double productsPrice, Double shippingPrice, Double discountAmount, 
	                               Double taxesPrice, Double totalPrice, HttpServletRequest request) {

	    User u = (User) request.getSession().getAttribute("user");
	    if (u == null) {
	        return "User not logged in";
	    }

	    orderService.processStep00(productsPrice, taxesPrice, shippingPrice, discountAmount, totalPrice, u.getId());
	    return "ok";
	}
	
    @RequestMapping("place-order-step-01")
    public String placeOrderStep01(String fullName, String phoneNumber, String address, String zipCode, String province, String city, String country, HttpServletRequest request) {
        // Validation patterns
        Pattern patternFullName = Pattern.compile(ValidationConstants.regExpShippingName, Pattern.CASE_INSENSITIVE);
        Pattern patternPhoneNumber = Pattern.compile(ValidationConstants.regExpPhoneNumber);
        Pattern patternAddress = Pattern.compile(ValidationConstants.regExpAddress, Pattern.CASE_INSENSITIVE);
        Pattern patternZipCode = Pattern.compile(ValidationConstants.regExpZipCode);
        Pattern patternProvince = Pattern.compile(ValidationConstants.regExpProvince, Pattern.CASE_INSENSITIVE);
        Pattern patternCity = Pattern.compile(ValidationConstants.regExpCity, Pattern.CASE_INSENSITIVE);
        Pattern patternCountry = Pattern.compile(ValidationConstants.regExpCountry, Pattern.CASE_INSENSITIVE);

        // Matchers
        Matcher matchesFullName = patternFullName.matcher(fullName);
        Matcher matchesPhoneNumber = patternPhoneNumber.matcher(phoneNumber);
        Matcher matchesAddress = patternAddress.matcher(address);
        Matcher matchesZipCode = patternZipCode.matcher(zipCode);
        Matcher matchesProvince = patternProvince.matcher(province);
        Matcher matchesCity = patternCity.matcher(city);
        Matcher matchesCountry = patternCountry.matcher(country);

        // Validation checks
        if (!matchesFullName.matches()) {
            return "incorrect full name from server side";
        }
        if (!matchesPhoneNumber.matches()) {
            return "incorrect phone number from server side";
        }
        if (!matchesAddress.matches()) {
            return "incorrect address from server side";
        }
        if (!matchesZipCode.matches()) {
            return "incorrect zip code from server side";
        }
        if (!matchesProvince.matches()) {
            return "incorrect province from server side";
        }
        if (!matchesCity.matches()) {
            return "incorrect city from server side";
        }
        if (!matchesCountry.matches()) {
            return "incorrect country from server side";
        }

        // Process order if all validations passed
        User u = (User) request.getSession().getAttribute("user");
        orderService.processStep01(fullName, phoneNumber, address, zipCode, province, city, country, u.getId());
        return "ok";
    }

    @RequestMapping("place-order-step-02")
    public String placeOrderStep02(String extraShippmentInformation, String timesReadComics, HttpServletRequest request) {
        // Validation pattern
        Pattern patternExtraShippingInfo = Pattern.compile(ValidationConstants.regExpExtraShippingInformation, Pattern.CASE_INSENSITIVE);
        Pattern patternTimesReadComics = Pattern.compile(ValidationConstants.regExpTimesReadComics, Pattern.CASE_INSENSITIVE);

        Matcher matchesTimesReadComics = patternTimesReadComics.matcher(timesReadComics);
        // Matcher
        if (extraShippmentInformation!=null) {
            Matcher matchesExtraShippingInfo = patternExtraShippingInfo.matcher(extraShippmentInformation);
            // Validation check
            if (!matchesExtraShippingInfo.matches()) {
                return "incorrect extra shipping information from server side";
            }
		}
        
        if (!matchesTimesReadComics.matches()) {
            return "incorrect information from server side";
        }
        
        // Process order if validation passed
        User u = (User) request.getSession().getAttribute("user");
        orderService.processStep02(extraShippmentInformation, timesReadComics, u.getId());
        return "ok";
    }

    @RequestMapping("place-order-step-03")
    public OrderSummary placeOrderStep03(String cardType, String cardNumber, String cardHolder, String cardExpirationDate,
                                          String cardCVV, HttpServletRequest request) {
        // Validation patterns
        Pattern patternCardType = Pattern.compile(ValidationConstants.regExpCardType, Pattern.CASE_INSENSITIVE);
        Pattern patternCardNumber = Pattern.compile(ValidationConstants.regExpCardNumber);
        Pattern patternCardHolder = Pattern.compile(ValidationConstants.regExpCardHolder, Pattern.CASE_INSENSITIVE);
        Pattern patternCardExpirationDate = Pattern.compile(ValidationConstants.regExpCardExpirationDate);
        Pattern patternCardCVV = Pattern.compile(ValidationConstants.regExpCardCVV);

        // Matchers
        Matcher matchesCardType = patternCardType.matcher(cardType);
        Matcher matchesCardNumber = patternCardNumber.matcher(cardNumber);
        Matcher matchesCardHolder = patternCardHolder.matcher(cardHolder);
        Matcher matchesCardExpirationDate = patternCardExpirationDate.matcher(cardExpirationDate);
        Matcher matchesCardCVV = patternCardCVV.matcher(cardCVV);

        if (!matchesCardType.matches()) {
        	
        }
        if (!matchesCardNumber.matches()) {

        }
        if (!matchesCardHolder.matches()) {

        }
        if (!matchesCardExpirationDate.matches()) {

        }
        if (!matchesCardCVV.matches()) {

        }

        // Process order if all validations passed
        User u = (User) request.getSession().getAttribute("user");
        orderService.processStep03(cardType, cardNumber, cardHolder, cardExpirationDate, cardCVV, u.getId());
        return orderService.getOrderSummary(u.getId());
    }

	 
	 @RequestMapping("confirm-order")
	 public String confirmOrder(HttpServletRequest request) {
		 User u = (User)request.getSession().getAttribute("user");
		 orderService.confirmOrder(u.getId());
		return "ok";
	 }
	 
}
