package com.prados.tiendaComics.constants;

public class Constants {
	public static final int MAX_PRODUCTS_IN_CART = 10;
}
