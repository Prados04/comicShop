package com.prados.tiendaComics.servicesJPAImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.prados.tiendaComics.model.Comic;
import com.prados.tiendaComics.model.Order;
import com.prados.tiendaComics.model.ProductCart;
import com.prados.tiendaComics.model.PromoCode;
import com.prados.tiendaComics.model.PromoCodeState;
import com.prados.tiendaComics.constants.Constants;
import com.prados.tiendaComics.constantsSQL.ConstantsSQL;
import com.prados.tiendaComics.model.Cart;
import com.prados.tiendaComics.model.User;
import com.prados.tiendaComics.services.CartService;
import com.prados.tiendaComics.utilities.Utilities;


@Service
@Transactional
public class ServiceCartJPAImpl implements CartService{

	@PersistenceContext
	private EntityManager entityManager;
	
	private int setProductCuantityInCart(boolean sum, int quantityInCart, int quantityToAdd) {
	    int maxProductsInCart = Constants.MAX_PRODUCTS_IN_CART;
	    int finalQuantityToAdd;
	    if (sum) {
	        if (quantityInCart + quantityToAdd > maxProductsInCart) {
	            finalQuantityToAdd = maxProductsInCart;
	        } else {
	            finalQuantityToAdd = quantityInCart + quantityToAdd;
	        }
	    } else {
	        if (quantityInCart - quantityToAdd < 0) {
	            finalQuantityToAdd = 1;
	        } else {
	            finalQuantityToAdd = quantityInCart - quantityToAdd;
	        }
	    }
	    return finalQuantityToAdd;
	}
	
	@Override
	public void addProduct(long idProduct, long idUser, int quantity) {
		User user = (User) entityManager.find(User.class, idUser);
		Cart cart = user.getCart();
		if (cart == null) {
			cart = new Cart();
			cart.setUser(user);
			user.setCart(cart);
			entityManager.persist(cart);
		}
		boolean productInCart = false;
		int finalQuantityToAdd = 0;
		for(ProductCart pc : cart.getProductCarts()) {
			if(pc.getComic().getId() == idProduct) {
				productInCart = true;
				finalQuantityToAdd = setProductCuantityInCart(true,pc.getQuantity(),quantity);
				pc.setQuantity(finalQuantityToAdd);
				entityManager.merge(pc);
			}
		}//end for
		if (! productInCart) {
			ProductCart pc = new ProductCart();
			pc.setShoppingCart(cart);
			pc.setComic(entityManager.find(Comic.class, idProduct));
			pc.setQuantity(quantity);
			entityManager.persist(pc);
		}
		
	}

	@Override
	public List<Map<String, Object>> getUserCartProducts(long idUser) {
		User user = entityManager.find(User.class, idUser);
		Cart cart = user.getCart();
		List<Map<String, Object>> res = new ArrayList<Map<String,Object>>();
		if(cart != null) {
			Query query = entityManager.createNativeQuery(
					ConstantsSQL.SQL_GET_CART_PRODUCTS);
			query.setParameter("cart_id", cart.getId());
			res = Utilities.processNativeQuery(query);
		}
		return res;
	}

	@Override
	public void deleteCartProduct(long idProduct, long idUser) {
	    User user = entityManager.find(User.class, idUser);
	    Cart cart = user.getCart();

	    ProductCart productCartToRemove = null;
	    for (ProductCart pc : cart.getProductCarts()) {
	        if (pc.getComic().getId() == idProduct) {
	            productCartToRemove = pc;
	            break;
	        }
	    }

	    if (productCartToRemove != null) {
	        cart.removeProductCart(productCartToRemove);
	        entityManager.remove(entityManager.merge(productCartToRemove));
	    }
	}

	@Override
	public void decreaseCartProduct(long idProduct, long idUser, Integer quantity) {
		User user = entityManager.find(User.class, idUser);
		Cart cart = user.getCart();
        for (ProductCart pc : cart.getProductCarts()) {
            if (pc.getComic().getId() == idProduct) {
	            int finalQuantity = setProductCuantityInCart(false, pc.getQuantity(), quantity);
	            pc.setQuantity(finalQuantity);
                entityManager.merge(pc);
            }
        }
	}

	@Override
	public void increaseCartProduct(long idProduct, long idUser, Integer quantity) {
	    User user = entityManager.find(User.class, idUser);
	    Cart cart = user.getCart();
	    for (ProductCart pc : cart.getProductCarts()) {
	        if (pc.getComic().getId() == idProduct) {
	            int finalQuantity = setProductCuantityInCart(true, pc.getQuantity(), quantity);
	            pc.setQuantity(finalQuantity);
	            entityManager.merge(pc);
	        }
	    }
	}

	@Override
	public boolean applyPromotionalCode(String promoCode, long id) throws Exception {
	    User user = entityManager.find(User.class, id);
	    Cart cart = user.getCart();
		PromoCode p = new PromoCode();
		
		@SuppressWarnings("unchecked")
		List<PromoCode> queryResult = entityManager.createQuery(
				"select p from PromoCode p where p.promoCodeName = :promoCode"
				).setParameter("promoCode", promoCode).getResultList();
		if(queryResult.size() == 1) {
			p = queryResult.get(0);
		}else if (queryResult.size() > 1) {
			throw new Exception("Something went wrong");
		}
		if (p != null && p.getCodeState() != PromoCodeState.EXPIRED.name() && p.getUsages() > 0) {
			entityManager.persist(cart);
			p.setUsages(p.getUsages()-1);
			entityManager.persist(p);
			cart.setPromoCode(p);
			entityManager.merge(cart);
			return true;
		}
		return false;
	}

	@Override
	public Map<String, Object> getUserCartPromoCode(long idUser) {
	    User user = entityManager.find(User.class, idUser);
	    if (user == null || user.getCart() == null) {
	        return Collections.emptyMap();
	    }
	    Cart cart = user.getCart();
	    Query query = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_CART_PROMO_CODE);
	    query.setParameter("cart_id", cart.getId());
	    List<Map<String, Object>> res = Utilities.processNativeQuery(query);
	    if (res.isEmpty()) {
	        return Collections.emptyMap();
	    }
	    return res.get(0);
	}

}
