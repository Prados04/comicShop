package com.prados.tiendaComics.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private com.prados.tiendaComics.serviceSetUp.SetUp setUp;
	
	@RequestMapping()
	public String home() {
		setUp.setUp();
		String actualLanguage = 
				messageSource.getMessage("language", null, LocaleContextHolder.getLocale());
		if (actualLanguage.equals("es")) {
			return "index_es";
		}
		return("index");
	}
}
