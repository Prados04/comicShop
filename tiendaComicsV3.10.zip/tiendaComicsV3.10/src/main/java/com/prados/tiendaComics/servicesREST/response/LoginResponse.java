package com.prados.tiendaComics.servicesREST.response;

public class LoginResponse {
	
	private String operation;
	
	private String username;

	public LoginResponse() {
		super();
	}

	public LoginResponse(String operation, String username) {
		super();
		this.operation = operation;
		this.username = username;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	
}
