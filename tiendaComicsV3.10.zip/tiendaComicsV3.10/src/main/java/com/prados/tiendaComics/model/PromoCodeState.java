package com.prados.tiendaComics.model;

public enum PromoCodeState {
	VALID,
	EXPIRED,
}
