package com.prados.tiendaComics.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class OrderPaymentSummary {
	
    private Double productsPrice;
    private Double taxesPrice;
    private Double shippingPrice;
    private Double discountAmount;
    private Double totalPrice;
    
    @Id
    @GeneratedValue
    private long id;
    
	public OrderPaymentSummary() {
		super();
	}
	
	public OrderPaymentSummary(Double productsPrice, Double taxesPrice, Double shippingPrice, Double discountAmount,
			Double totalPrice) {
		super();
		this.productsPrice = productsPrice;
		this.taxesPrice = taxesPrice;
		this.discountAmount = discountAmount;
		this.shippingPrice = shippingPrice;
		this.totalPrice = totalPrice;
	}

	public Double getProductsPrice() {
		return productsPrice;
	}
	public void setProductsPrice(Double productsPrice) {
		this.productsPrice = productsPrice;
	}
	public Double getShippingPrice() {
		return shippingPrice;
	}
	public void setShippingPrice(Double shippingPrice) {
		this.shippingPrice = shippingPrice;
	}
	public Double getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(Double discountAmount) {
		this.discountAmount = discountAmount;
	}
	public Double getTaxesPrice() {
		return taxesPrice;
	}
	public void setTaxesPrice(Double taxesPrice) {
		this.taxesPrice = taxesPrice;
	}
	public Double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
    
}