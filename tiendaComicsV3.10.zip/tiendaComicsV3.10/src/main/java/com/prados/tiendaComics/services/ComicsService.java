package com.prados.tiendaComics.services;

import java.util.List;
import java.util.Map;

import com.google.gson.JsonElement;
import com.prados.tiendaComics.model.Comic;

public interface ComicsService {

	void registerComic(Comic c);
	
	List<Comic> getComics();
	
	List<Comic> getComics(String title);
	
	List<Comic> getComics(String title, int start, int resultsPerPage);
	
	void deleteComic(Long id);
	
	Comic getComicById(Long id);
	
	void updateComic(Comic c);

	Map<String, Object> getComicViewDetailsById(Long id);

	List<Map<String, Object>> getComicsForList();
	
	List<Map<String, Object>> getComicsForList(String title, int start, String editorial, String extra_things);

	int getTotalComics(String title, String editorial, String extra_things);

	int getTotalComics();

	int getTotalComics(String title);


}
