package com.prados.tiendaComics.servicesJPAImpl;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Service;
import com.prados.tiendaComics.model.Category;
import com.prados.tiendaComics.model.Comic;
import com.prados.tiendaComics.services.CategoriesService;
import javax.persistence.EntityNotFoundException;

@Service
@Transactional
public class ServiceCategoriesJPAImpl implements CategoriesService {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Category> getCategories() {
        TypedQuery<Category> query = entityManager.createQuery("SELECT c FROM Category c", Category.class);
        return query.getResultList();
    }

    @Override
    public Category getCategoryById(int id) {
        Category category = entityManager.find(Category.class, id);
        if (category == null) {
            throw new EntityNotFoundException("Category not found with id: " + id);
        }
        return category;
    }

    @Override
    public void deleteCategory(int id) {
        Category category = getCategoryById(id);
        List<Comic> comics = entityManager.createQuery("SELECT c FROM Comic c WHERE c.category.id = :categoryId", Comic.class)
            .setParameter("categoryId", id)
            .getResultList();
        
        for (Comic comic : comics) {
            comic.setCategory(null);
            entityManager.merge(comic);
        }
        
        entityManager.remove(category);
    }

    @Override
    public void registerCategory(Category newCategory) {
        entityManager.persist(newCategory);
    }

    @Override
    public void updateCategory(Category editCategory) {
        Category existingCategory = getCategoryById(editCategory.getId());
        existingCategory.setName(editCategory.getName());
        existingCategory.setDescription(editCategory.getDescription());
        
        // We don't touch the comics here to prevent accidental deletion
        // If you need to update comic associations, handle it separately
        
        entityManager.merge(existingCategory);
    }
}