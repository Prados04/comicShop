package com.prados.tiendaComics.servicesJPAImpl;


import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.prados.tiendaComics.constantsSQL.ConstantsSQL;
import com.prados.tiendaComics.model.Category;
import com.prados.tiendaComics.model.User;
import com.prados.tiendaComics.services.UsersService;
import com.prados.tiendaComics.utilities.Utilities;

@Service
@Transactional
public class ServiceUsersJPAImpl implements UsersService{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void signUpUser(User u) {
		entityManager.persist(u);
	}

	@Override
	public boolean checkExistEmail(String email) {
		Query query = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_USER_ID_BY_EMAIL);
		query.setParameter("email", email);
		List<Map<String, Object>> res = Utilities.processNativeQuery(query);
			return !res.isEmpty();

	}

	@Override
	public boolean checkExistUsername(String username) {
		Query query = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_USER_ID_BY_USERNAME);
		query.setParameter("username", username);
		List<Map<String, Object>> res = Utilities.processNativeQuery(query);
			return !res.isEmpty();
	}

	@Override
	public boolean checkExistPhoneNumber(String telNumber) {
		Query query = entityManager.createNativeQuery(ConstantsSQL.SQL_GET_USER_ID_BY_PHONE);
		query.setParameter("telNumber", telNumber);
		List<Map<String, Object>> res = Utilities.processNativeQuery(query);
			return !res.isEmpty();
	}

	@Override
	public User getUserByCredentialAndPass(String credential, String pass) {
		Query query = entityManager.createQuery(
			    "SELECT u FROM User u WHERE (u.email = :credential OR u.username = :credential OR u.telNumber = :credential) AND u.pass = :pass"
		);
		query.setParameter("credential", credential);
		query.setParameter("pass", pass);
		@SuppressWarnings("unchecked")
		List<User> result=query.getResultList();
		if (result.size()==0) {
			return null;	
		}else {
			return result.get(0);
		}
	}

	@Override
	public List<User> getUsers() {
		System.err.println("Get user");
		return entityManager.createQuery("select u from User u").getResultList();
	}

	@Override
	public void deleteUser(long id) {
		User u = entityManager.find(User.class, id);
		entityManager.remove(u);
	}

	@Override
	public void registerUser(User newUser) {
		entityManager.persist(newUser);
	}

	@Override
	public User getUserById(long id) {
		return entityManager.find(User.class, id);
	}

    @Override
    public void updateUser(User editUser) {
        User existingUser = getUserById(editUser.getId());
        
        // Update basic user information
        existingUser.setUsername(editUser.getUsername());
        existingUser.setEmail(editUser.getEmail());
        existingUser.setName(editUser.getName());
        existingUser.setSecondName(editUser.getSecondName());
        existingUser.setTelNumber(editUser.getTelNumber());
        
        // Update password only if a new one is provided
        if (editUser.getPass() != null && !editUser.getPass().isEmpty()) {
            existingUser.setPass(editUser.getPass());
        }
        
        // Update cart if provided
        if (editUser.getCart() != null) {
            if (existingUser.getCart() == null) {
                existingUser.setCart(editUser.getCart());
            } else {
                existingUser.getCart().setPromoCode(editUser.getCart().getPromoCode());
                existingUser.getCart().setLastUsage(editUser.getCart().getLastUsage());
                // Update cart items if necessary
            }
        }
        
        // Update extra user information if provided
        if (editUser.getExtraUserInformation() != null) {
            if (existingUser.getExtraUserInformation() == null) {
                existingUser.setExtraUserInformation(editUser.getExtraUserInformation());
            } else {
                existingUser.getExtraUserInformation().setTimesReadComics(editUser.getExtraUserInformation().getTimesReadComics());
            }
        }
        
        // We don't touch the orders here to prevent accidental deletion
        // If you need to update order associations, handle it separately
        
        entityManager.merge(existingUser);
    }

}
