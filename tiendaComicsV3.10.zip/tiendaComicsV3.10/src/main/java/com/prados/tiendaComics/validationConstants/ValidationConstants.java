package com.prados.tiendaComics.validationConstants;

public class ValidationConstants {
	
	public final static String regExpNameUserSignUp = "^[a-z ñáéíóú]{2,20}$"; // Allows letters, spaces, and accented characters, between 2 to 10 characters
	public final static String regExpEmailUserSignUp = "^[a-z0-9._%+-ñ]+@[a-z0-9.-]+\\.[a-z]{2,}$"; // Matches common email format
	public final static String regExpPassUserSignUp = "^(?=.*[A-Zñáéíóú])(?=.*\\d)(?=.*[!@#$%^&*()_+,.?;:\\\\])[A-Za-zñáéíóú\\d!@#$%^&-*()_+,.?;:\\\\]{6,30}$"; // Allows lowercase letters, numbers, and accented characters, between 3 to 10 characters
	public final static String regExpUsernameUserSignUp = "^[a-z0-9_ñáéíóú]{3,15}$"; // Allows letters, numbers, underscores, between 3 to 15 characters
	public final static String regExpSecondNameUserSignUp = "^[a-z0-9_ñáéíóú]{3,15}$"; // Allows letters, spaces, and accented characters, between 2 to 15 characters
	public final static String regExpTelNumberUserSignUp = "^\\d{9,15}$"; // Only digits, between 9 to 15 characters
	
	public final static String regExpShippingName = "^[a-zA-Z ñáéíóú]{2,30}$"; // Allows letters, spaces, and accented characters, between 2 to 30 characters
	public final static String regExpPhoneNumber = "^\\d{3,15}$"; // Only digits, between 3 to 15 characters
	public final static String regExpCity = "^[a-z ñáéíóú]{2,30}$"; // Allows letters, spaces, and accented characters, between 2 to 30 characters
	public final static String regExpCountry = "^[a-z ñáéíóú]{2,30}$"; // Allows letters, spaces, and accented characters, between 2 to 30 characters
	public final static String regExpProvince = "^[a-z ñáéíóú]{2,30}$"; // Allows letters, spaces, and accented characters, between 2 to 30 characters
	public final static String regExpAddress = "^[a-z0-9 /ñáéíóú#.,-º]{5,100}$"; // Allows letters, numbers, spaces, and certain special characters, between 5 to 100 characters
	public final static String regExpZipCode = "^\\d{1,10}$"; // Only digits, between 1 to 10 characters (common for ZIP codes)

	public final static String regExpExtraShippingInformation = "^[a-z0-9 ñáéíóú.,#-]{0,100}$"; // Allows letters, numbers, spaces, and common punctuation, up to 100 characters
	public final static String regExpTimesReadComics= "^[0-9_+-]{0,5}$"; // Allows letters, numbers, underscores, between 3 to 15 characters
	
	public final static String regExpCardType = "^[a-zA-Z_\\s]+$"; // Allows letters and spaces for card types
	public final static String regExpCardNumber = "^\\d{10,20}$"; // 10 to 20 digits for card numbers
	public final static String regExpCardHolder = "^[a-zA-Z ñáéíóú]{3,50}$"; // Allows letters, spaces, and accented characters, between 3 to 50 characters
	public final static String regExpCardExpirationDate = "^(0[1-9]|1[0-2])\\/([0-9]{2})$"; // MM/YY format
	public final static String regExpCardCVV = "^\\d{3,4}$"; // 3 or 4 digits for CVV
	
	public final static String regExpQuantity = "^([0-9]|10)$"; // Allows numbers 1 to 10
}
