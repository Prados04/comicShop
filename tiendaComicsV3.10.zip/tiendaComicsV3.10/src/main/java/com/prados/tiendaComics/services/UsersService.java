package com.prados.tiendaComics.services;

import java.util.List;

import javax.validation.Valid;

import com.prados.tiendaComics.model.User;

public interface UsersService {

	void signUpUser(User u);

	boolean checkExistEmail(String email);
	
	boolean checkExistUsername(String username);

	boolean checkExistPhoneNumber(String telNumber);

	User getUserByCredentialAndPass(String credential, String pass);

	List<User> getUsers();

	void deleteUser(long id);

	void registerUser(User newUser);

	User getUserById(long id);

	void updateUser(User editUser);
}
