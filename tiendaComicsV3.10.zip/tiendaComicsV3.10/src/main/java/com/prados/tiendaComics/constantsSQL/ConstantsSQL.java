package com.prados.tiendaComics.constantsSQL;

public class ConstantsSQL {

	public final static String SQL_GET_COMIC_DETAILS =
			"SELECT c.title, c.editorial, c.author, c.isbn, c.release_date, c.description, c.price, c.series, c.id FROM table_comics AS c WHERE c.id = :id";
	public static final String SQL_GET_COMICS_LIST = 
			"SELECT c.title, c.price, c.series, c.id FROM table_comics AS c";
	public static final String SQL_GET_COMICS_LIST_BY_INCLUDING_TITTLE_START =
			"SELECT c.title, c.price, c.series, c.id FROM table_comics AS c WHERE c.title LIKE :title ORDER BY c.id DESC LIMIT :start, 10";
	public static final String SQL_GET_COMICS_LIST_BY_TITLE_AND_EDITORIAL = 
			"SELECT c.title, c.price, c.series, c.id FROM table_comics AS c WHERE c.title LIKE :title AND c.editorial LIKE :editorial ORDER BY c.id DESC LIMIT :start, 10";;
	public static final String SQL_GET_COMICS_LIST_EXCLUDING_EDITORIALS = 
			"SELECT c.title, c.price, c.series, c.id FROM table_comics AS c WHERE c.title LIKE :title AND c.editorial NOT IN ('Marvel', 'DC') ORDER BY c.id DESC LIMIT :start, 10";
	public static final String SQL_GET_COMICS_ORDER_BY_SALES = 
			"SELECT c.title, c.price, c.series, c.id FROM table_comics AS c WHERE c.title LIKE :title ORDER BY c.sales DESC LIMIT :start, 10";
	public static final String SQL_GET_CART_PRODUCTS = 
			"SELECT tc.id, tc.title, tc.price, pc.quantity "
			+ "FROM table_comics AS tc, product_cart AS pc "
			+ "WHERE pc.comic_id = tc.id and pc.cart_id = :cart_id "
			+ "ORDER BY tc.price DESC";
	public static final String SQL_DELETE_CART_PRODUCT = 
			"DELETE FROM product_cart WHERE cart_id = :cart_id";
	public static final String SQL_GET_USER_ID_BY_EMAIL = 
			"SELECT id FROM table_users WHERE email = :email";
	public static final String SQL_GET_USER_ID_BY_USERNAME = 
			"SELECT id FROM table_users WHERE username = :username";
	public static final String SQL_GET_USER_ID_BY_PHONE =
			"SELECT id FROM table_users WHERE tel_number = :telNumber";
	public static final String SQL_GET_TOTAL_COMICS = 
			"SELECT count(id) FROM table_comics";
	public static final String SQL_GET_TOTAL_COMICS_BY_TITLE = 
			"SELECT count(id) FROM table_comics WHERE title LIKE :title";
	
	public static final String SQL_GET_TOTAL_COMICS_BY_EXCLUDING_EDITORIALS = 
	        "SELECT count(id) FROM table_comics WHERE title LIKE :title AND editorial NOT IN ('Marvel', 'DC')";

	public static final String SQL_GET_TOTAL_COMICS_BY_TITLE_AND_EDITORIALS = 
	        "SELECT count(id) FROM table_comics WHERE title LIKE :title AND editorial LIKE :editorial";
	public static final String SQL_GET_CART_PROMO_CODE = 
			"SELECT p.* FROM cart AS c, promo_code AS p WHERE c.id = :cart_id AND p.id = c.promo_code_id LIMIT 1";
	
}
