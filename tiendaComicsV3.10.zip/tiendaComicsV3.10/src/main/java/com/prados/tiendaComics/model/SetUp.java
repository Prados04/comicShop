package com.prados.tiendaComics.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class SetUp {
	
	private boolean complete;
	
	@Id
	@GeneratedValue
	private int id;

	public SetUp() {
		super();
		// TODO Auto-generated constructor stub
	}

	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	

}
