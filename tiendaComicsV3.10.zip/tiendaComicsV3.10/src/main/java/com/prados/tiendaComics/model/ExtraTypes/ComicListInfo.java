package com.prados.tiendaComics.model.ExtraTypes;

import java.util.List;
import java.util.Map;

public class ComicListInfo {

	private List<Map<String, Object>> comics;
	private int comicsTotal;
	public List<Map<String, Object>> getComics() {
		return comics;
	}
	public void setComics(List<Map<String, Object>> comics) {
		this.comics = comics;
	}
	public int getComicsTotal() {
		return comicsTotal;
	}
	public void setComicsTotal(int comicsTotal) {
		this.comicsTotal = comicsTotal;
	}
	
}
