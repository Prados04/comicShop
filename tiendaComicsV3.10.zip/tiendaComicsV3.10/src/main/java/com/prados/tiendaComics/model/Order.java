package com.prados.tiendaComics.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "table_orders")
public class Order {
	
	@OneToMany(mappedBy = "order",cascade = CascadeType.ALL)
	private List<OrderProduct> productsOrder =
		new ArrayList<OrderProduct>();
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "order_payment_summary_id")
	private OrderPaymentSummary orderPaymentSummary;
	
	private String state;
	
	//Step 01
	private String fullName;
	
	private String address;
	
	private String zipCode;
	
	private String province;
	
	private String city;
	
	private String country;
	
	private String phoneNumber;
	//End Step 01
	
	//Step 03
	private String extraShippmentInformation;
	//End Step 03
	
	//Step 03
	private String cardType;
	
	private String cardNumber;
	
	private String cardExpirationDate;
	
	private String cardCVV;
	
	private String cardHolder;
	//End Step 03
	
	private int totalProductPrice;
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;
	
	@Id
	@GeneratedValue
	private long id;
	
	
	
	public Order() {
		super();
		this.orderPaymentSummary = new OrderPaymentSummary();
	}

	
	public Order(List<OrderProduct> productsOrder, OrderPaymentSummary orderPaymentSummary, String state,
			String fullName, String address, String zipCode, String province, String city, String country,
			String phoneNumber, String extraShippmentInformation, String cardType, String cardNumber,
			String cardExpirationDate, String cardCVV, String cardHolder, int totalProductPrice, User user, long id) {
		super();
		this.productsOrder = productsOrder;
		this.orderPaymentSummary = orderPaymentSummary;
		this.state = state;
		this.fullName = fullName;
		this.address = address;
		this.zipCode = zipCode;
		this.province = province;
		this.city = city;
		this.country = country;
		this.phoneNumber = phoneNumber;
		this.extraShippmentInformation = extraShippmentInformation;
		this.cardType = cardType;
		this.cardNumber = cardNumber;
		this.cardExpirationDate = cardExpirationDate;
		this.cardCVV = cardCVV;
		this.cardHolder = cardHolder;
		this.totalProductPrice = totalProductPrice;
		this.user = user;
		this.id = id;
		this.orderPaymentSummary = new OrderPaymentSummary();
	}

	public OrderPaymentSummary getOrderPaymentSummary() {
		return orderPaymentSummary;
	}

	public void setOrderPaymentSummary(OrderPaymentSummary orderPaymentSummary) {
		this.orderPaymentSummary = orderPaymentSummary;
	}

	public int getTotalProductPrice() {
		return totalProductPrice;
	}

	public void setTotalProductPrice(int totalProductPrice) {
		this.totalProductPrice = totalProductPrice;
	}

	public List<OrderProduct> getProductsOrder() {
		return productsOrder;
	}

	public void setProductsOrder(List<OrderProduct> productsOrder) {
		this.productsOrder = productsOrder;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}
	
	public String getExtraShippmentInformation() {
		return extraShippmentInformation;
	}

	public void setExtraShippmentInformation(String extraShippmentInformation) {
		this.extraShippmentInformation = extraShippmentInformation;
	}

	public String getCardHolder() {
		return cardHolder;
	}

	public void setCardHolder(String cardHolder) {
		this.cardHolder = cardHolder;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	

	public String getCardExpirationDate() {
		return cardExpirationDate;
	}

	public void setCardExpirationDate(String cardExpirationDate) {
		this.cardExpirationDate = cardExpirationDate;
	}

	public String getCardCVV() {
		return cardCVV;
	}

	public void setCardCVV(String cardCVV) {
		this.cardCVV = cardCVV;
	}

	public User getUser() {
		return user;
	}

    public void setUser(User user) {
        this.user = user;
    }

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Order [productsOrder=" + productsOrder + ", state=" + state + ", fullName=" + fullName + ", address="
				+ address + ", zipCode=" + zipCode + ", province=" + province + ", city=" + city + ", country="
				+ country + ", phoneNumber=" + phoneNumber + ", cardType=" + cardType + ", cardNumber=" + cardNumber
				+ ", cardExpirationDate=" + cardExpirationDate + ", cardCVV=" + cardCVV + ", cardHolder=" + cardHolder
				+ ", user=" + user + ", id=" + id + "]";
	}
	
	
	
}
