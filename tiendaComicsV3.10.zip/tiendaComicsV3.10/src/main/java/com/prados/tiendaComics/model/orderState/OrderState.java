package com.prados.tiendaComics.model.orderState;

public enum OrderState {
	
	INCOMPLETE,
	COMPLETE,
	FINISHED
}
