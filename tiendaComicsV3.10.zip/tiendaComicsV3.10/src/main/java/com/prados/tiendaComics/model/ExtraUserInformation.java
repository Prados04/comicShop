package com.prados.tiendaComics.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class ExtraUserInformation {
	
	private String timesReadComics;
	
	private boolean offers;
	
	private boolean newsletter;
	
	@OneToOne(mappedBy = "extraUserInformation")
	private User user;
	
	@Id
	@GeneratedValue
	private Long id;

	public String getTimesReadComics() {
		return timesReadComics;
	}

	public void setTimesReadComics(String timesReadComics) {
		this.timesReadComics = timesReadComics;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public boolean isOffers() {
		return offers;
	}

	public void setOffers(boolean offers) {
		this.offers = offers;
	}

	public boolean isNewsletter() {
		return newsletter;
	}

	public void setNewsletter(boolean newsletter) {
		this.newsletter = newsletter;
	}
	
	
	
	
}
