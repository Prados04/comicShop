package com.prados.tiendaComics.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class PromoCode {
	private String promoCodeName;
	private int discount;
	private String promoCodeType;
	private int usages;
	private String codeState;

	@Id
	@GeneratedValue
	private int id;
	
	public PromoCode() {
		super();
	}
	public PromoCode(String promoCodeName, int discount, String promoCodeType, int usages, String codeState, int id) {
		super();
		this.promoCodeName = promoCodeName;
		this.discount = discount;
		this.promoCodeType = promoCodeType;
		this.usages = usages;
		this.codeState = codeState;
		this.id = id;
	}
	public String getPromoCodeType() {
		return promoCodeType;
	}
	public void setPromoCodeType(String promoCodeType) {
		this.promoCodeType = promoCodeType;
	}
	public String getCodeState() {
		return codeState;
	}
	public void setCodeState(String codeState) {
		this.codeState = codeState;
	}
	public String getPromoCodeName() {
		return promoCodeName;
	}
	public void setPromoCodeName(String promoCodeName) {
		this.promoCodeName = promoCodeName;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUsages() {
		return usages;
	}
	public void setUsages(int usages) {
		this.usages = usages;
	}
	
	
	
	
}
