package com.prados.tiendaComics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaComicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaComicsApplication.class, args);
	}

}
