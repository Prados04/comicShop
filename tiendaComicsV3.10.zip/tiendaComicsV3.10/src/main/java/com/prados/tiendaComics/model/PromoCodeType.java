package com.prados.tiendaComics.model;

import javax.persistence.Entity;

public enum PromoCodeType {
		PERCENTAGE,
		STATIC_PRICE,
	    FREE_SHIPPING
}
